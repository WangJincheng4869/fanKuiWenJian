import 'vue-router'

declare module 'vue-router' {
  interface RouteMeta {
    /**
     * 是否保活
     */
    keepAlive?: boolean
  }
}