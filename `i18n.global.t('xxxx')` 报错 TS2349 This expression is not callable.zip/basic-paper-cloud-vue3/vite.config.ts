import {defineConfig} from 'vite'
import vue from '@vitejs/plugin-vue'
import {compression} from 'vite-plugin-compression2'
import {resolve} from "path";
import VueI18nPlugin from "@intlify/unplugin-vue-i18n/vite";

// https://vitejs.dev/config/
export default defineConfig({
  server: {
    host: '0.0.0.0',
    port: 8180
  },
  resolve: {
    alias: {
      '@': resolve(__dirname, './src')
    }
  },
  plugins: [
    vue(),
    // https://github.com/intlify/bundle-tools/tree/main/packages/vite-plugin-vue-i18n
    VueI18nPlugin({
      runtimeOnly: true,
      compositionOnly: true,
      include: [resolve("locale/**")]
    }),
    compression({exclude: [/\.(br)$/, /\.(gz)$/]}),
    compression({algorithm: 'brotliCompress', exclude: [/\.(br)$/, /\.(gz)$/]})
  ]
})
