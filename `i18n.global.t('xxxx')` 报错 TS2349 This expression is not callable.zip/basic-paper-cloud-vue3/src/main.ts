import {createApp} from 'vue'
import App from './App.vue'
import Router from "./router";
import './index.scss'
import './tailwind.css'
import ElementPlus from 'element-plus'
import {createPinia} from 'pinia'
import {initApplicationConfig} from "./config";
import {authScheduled} from "./scheduled/auth-scheduled";
import {i18n} from "@/config/i18n";

const pinia = createPinia()
let app = createApp(App);
app.use(pinia);

initApplicationConfig().then(() => {
  app.use(Router).use(i18n).use(ElementPlus).mount('#app')
  // 开启自动更新token定时任务
  authScheduled.refreshToken()
})