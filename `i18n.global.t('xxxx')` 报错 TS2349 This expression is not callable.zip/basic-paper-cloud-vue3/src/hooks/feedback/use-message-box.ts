import { i18n } from "@/config/i18n";
import {ElMessageBox, ElMessageBoxOptions} from "element-plus";

class UseMessageBox {

  /**
   * 当用户进行操作时会被触发，该对话框中断用户操作，直到用户确认知晓后才可关闭。<br>
   * 调用 ElMessageBox.alert 方法以打开 alert 框。 它模拟了系统的 alert，无法通过按下 ESC 或点击框外关闭。 此例中接收了两个参数，message和title。 值得一提的是，窗口被关闭后，它默认会返回一个Promise对象便于进行后续操作的处理。 若不确定浏览器是否支持Promise，可自行引入第三方 polyfill 或像本例一样使用回调进行后续处理。
   * @param msg 消息内容
   * @param title 标题
   * @param options 配置参数，详见https://element-plus.org/zh-CN/component/message-box.html#messagebox-%E9%85%8D%E7%BD%AE%E9%A1%B9
   */
  public alert(msg: string, title = i18n.global.t('messageBox.title.tip'), options?: (ElMessageBoxOptions | undefined)) {
    return ElMessageBox.alert(msg, title, options);
  }

  /**
   * 普通的询问框，提示用户确认其已经触发的动作，并询问是否进行此操作时会用到此对话框。<br>
   * 调用 ElMessageBox.confirm 方法以打开 confirm 框。它模拟了系统的 confirm。 Message Box 组件也拥有极高的定制性，我们可以传入 options 作为第三个参数，它是一个字面量对象。 type 字段表明消息类型，可以为success，error，info和 warning，无效的设置将会被忽略。 需要注意的是，第二个参数 title 必须定义为 String 类型，如果是 Object，会被当做为 options使用。 在这里我们返回了一个 Promise 来处理后续响应。
   * @param msg 消息内容
   * @param title 标题
   * @param options 配置参数，详见https://element-plus.org/zh-CN/component/message-box.html#messagebox-%E9%85%8D%E7%BD%AE%E9%A1%B9
   * @returns {*}
   */
  public confirm(msg: string, title = i18n.global.t('messageBox.title.tip'), options?: (ElMessageBoxOptions | undefined)) {
    return ElMessageBox.confirm(msg, title, options)
  }

  /**
   * 警告询问框，就是confirm添加了默认的参数{type: 'warning'}
   * @param msg 消息
   * @param title 标题
   * @returns {*}
   */
  public warningConfirm(msg: string, title = i18n.global.t('messageBox.title.warning')) {
    return ElMessageBox.confirm(msg, title, {type: 'warning'})
  }
}

export const useMessageBox = new UseMessageBox();