/**
 * 返回AccessToken数据模型
 *
 * @author 王金城
 * @date 2022/4/21
 **/
export interface AccessTokenDTO {
  /**
   * JWT登录凭证
   **/
  accessToken: string;
  /**
   * 获取新的JWT登录凭证的凭证
   **/
  refreshToken: string;
  /**
   * 凭证有效时间，单位：秒
   **/
  expiresIn: number;
}