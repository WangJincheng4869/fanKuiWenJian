export class ResultStatusConsts {
  /**
   * 请求成功
   */
  public static readonly SUCCESS: 10000;

  /**
   * 服务不可用
   */
  public static readonly SERVER_NOT_AVAILABLE: 20000;

  /**
   * 授权权限不足
   */
  public static readonly INSUFFICIENT_PERMISSION: 20001;

  /**
   * 非法参数：缺少必选参数或必填为null
   */
  public static readonly ILLEGAL_PARAM_NULL: 40000;

  /**
   * 非法参数：存在非法字符
   */
  public static readonly ILLEGAL_PARAM_CHAR: 40001;

  /**
   * <p>非法参数：存在无效的参数</p>
   * <p>例如配置表中的配置项，传入非配置项的参数</p>
   */
  public static readonly ILLEGAL_PARAM_INVALID: 40002;

  /**
   * <p>非法参数：加密参数无效</p>
   * <p>需要加密参数的参数，无法进行解密</p>
   */
  public static readonly ILLEGAL_PARAM_ENCRYPTION_INVALID: 40003;

  /**
   * <p>禁止操作：数据被占用</p>
   * <p>例如：如果该条数据正在被使用，不能被修改或删除</p>
   */
  public static readonly PROHIBIT_OPERATE_DATA_OCCUPY: 40004;
  /**
   * <p>禁止操作：状态异常</p>
   */
  public static readonly PROHIBIT_OPERATE_ABNORMAL_STATE: 40005;
  /**
   * 系统异常
   */
  public static readonly ERROR_SYSTEM: 50000;
}
