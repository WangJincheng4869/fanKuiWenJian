import {createRouter, createWebHistory, RouteRecordRaw} from 'vue-router';
import Login from "../module/sso/components/Login.vue";
import Main from "../layout/components/Main.vue";
import {authUtils} from "@/util/auth/auth-utils";
import {ResultStatusConsts} from "@/util/http/constant/result-status-consts";
import {ajax} from "@/util/http/ajax-utils";
import {useAuthStore} from "@/store/auth";

// 读取系统全部的子路由
let modulesChildrenRouteRecord: Record<string, any> = import.meta.glob(['../module/**/router/children-*.ts'], {eager: true});
// 子路由集合
const childrenRoutes: RouteRecordRaw[] = [];

// 子路由页面导入，需要在框架内部打开的路由页面
Object.keys(modulesChildrenRouteRecord).forEach(key => {
  let routes: RouteRecordRaw[] = modulesChildrenRouteRecord[key].default;
  routes.forEach((route) => {
    childrenRoutes.push(route)
  })
});

// 路由配置
const routes: RouteRecordRaw[] = [
  {
    path: '/',
    name: 'MainPage',
    component: Main,
    children: childrenRoutes
  }, {
    path: '/login',
    name: 'LoginPage',
    component: Login
  }
]

let modulesRouteRecord: Record<string, any> = import.meta.glob(['../module/**/router/index.ts'], {eager: true});
// 模块主路由添加，不需要在内部打开，需要全屏打开的页面。例如：登录页
Object.keys(modulesRouteRecord).forEach(key => {
  let modulesRoutes: RouteRecordRaw[] = modulesRouteRecord[key].default;
  modulesRoutes.forEach((route) => {
    routes.push(route)
  })
});

const router = createRouter({
  history: createWebHistory(import.meta.env.BASE_URL),
  routes,
})

router.beforeEach(async (to) => {
  if (to.name === 'LoginPage') {
    return true;
  }
  // 如果是携带者ticket的请求，则代表是需要进行换取AccessToken
  if (to.query.ticket) {
    await ajax.get('/sso_auth/web/get_access_token').then(result => {
      if (result.status === ResultStatusConsts.SUCCESS) {
        // 获取token成功，将token存入sessionStorage中
        authUtils.updateToken(result.data)
        // 去除ticket参数并跳转
        window.location.href = to.fullPath.replaceAll(/[?&]ticket=.*/g, '');
      } else {
        console.error(`登录失败！通过ticket换取token失败 ${result}`)
        return {name: 'LoginPage'}
      }
    }).catch(reason => {
      console.error(`登录失败！通过ticket换取token接口请求失败 ${reason}`)
    })
  }
  // 检查用户是否已登录，路由守卫里的时间差比较激进，为了防止定时器还没有来得及刷新token
  if (useAuthStore().tokenTimeout - Date.now() < 60000) {
    // 将用户重定向到登录页面
    console.warn(`登录已过期，需要重新登录!!! 路由地址=${to.fullPath}`)
    authUtils.setLoginRedirectUrl(to.fullPath);
    return {name: 'LoginPage'}
  }
})

export default router;