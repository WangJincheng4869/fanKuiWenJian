import {authUtils} from "@/util/auth/auth-utils";
import {ajax} from "@/util/http/ajax-utils";
import {useApplicationConfigStore} from "@/store/application-config";
import {ResultStatusConsts} from "@/util/http/constant/result-status-consts";

class AuthScheduled {

  /**
   * 定时刷新token，每10秒执行一次
   */
  public refreshToken() {
    // 如果超时了则进行token的更新，刷新token的前提是要存在token
    if (authUtils.getAccessToken() && authUtils.isTimeout()) {
      let {ssoApiBaseUrl} = useApplicationConfigStore();
      ajax.get(`${ssoApiBaseUrl}/sso_auth/web/refresh_access_token`, null, 2000).then(result => {
        if (result.status === ResultStatusConsts.SUCCESS) {
          authUtils.updateToken(result.data);
        } else {
          console.error(`定期刷新token失败 ${result}`)
        }
      }).catch(reason => {
        console.error(`定期刷新token失败 ${reason}`)
      })
    }
    setTimeout(authScheduled.refreshToken, 1000 * 10)
  }

}

export const authScheduled = new AuthScheduled();