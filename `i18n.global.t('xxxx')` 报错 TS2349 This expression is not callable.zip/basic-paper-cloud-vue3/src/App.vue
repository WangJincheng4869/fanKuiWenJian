<script setup lang="ts">
import {ElConfigProvider} from 'element-plus';
import zhCN from 'element-plus/lib/locale/lang/zh-cn';
import en from 'element-plus/lib/locale/lang/en';
import {i18nUtils} from "@/config/i18n";
import {computed} from "vue";

let {getLocale} = i18nUtils();

const locale = computed(() => {
  switch (getLocale()) {
    case "zh-CN":
      return zhCN
    case "en":
      return en
    default:
      return zhCN
  }
})
</script>

<template>
  <el-config-provider :locale="locale">
    <!-- 路由匹配到的组件将渲染在这里 -->
    <router-view></router-view>
  </el-config-provider>
</template>

<style scoped>
</style>
