<script setup lang="ts">
import {ref} from "vue";
import {useApplicationConfigStore} from "@/store/application-config";
import {i18nUtils} from "@/config/i18n";
import {useMessageBox} from "@/hooks/feedback/use-message-box";

const v = ref(useApplicationConfigStore().ssoApiBaseUrl)
const x = () => {
  console.log(useApplicationConfigStore().ssoApiBaseUrl)
  useMessageBox.alert('啊啊啊')
}
const {switchI18n, getLocale, locales} = i18nUtils();
const locale = ref(getLocale())

</script>

<template>
  <el-input v-model="v" :placeholder="$t('btn.save')" @click="x"/>
  <span>{{ $t('btn.del') }}</span>
  <el-select class="locale" v-model="locale" @change="switchI18n(locale)" size="small">
    <el-option v-for="(value, key) in locales" :key="key" :value="key" :label="value"></el-option>
  </el-select>
</template>

<style scoped>
.locale{
  width: 90px;
}
</style>