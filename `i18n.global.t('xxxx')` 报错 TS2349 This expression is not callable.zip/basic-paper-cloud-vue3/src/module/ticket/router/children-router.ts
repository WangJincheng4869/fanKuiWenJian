import {RouteRecordRaw} from "vue-router";

export default [
  {
    path: '/ticket',
    name: 'ticket',
    component: () => import("@/module/ticket/components/TicketInfo.vue"),
    meta: {}
  }, {
    path: '/ticket1',
    name: 'ticket1',
    component: () => import("@/module/ticket/components/TicketInfo1.vue"),
    meta: {}
  }
] as Array<RouteRecordRaw>