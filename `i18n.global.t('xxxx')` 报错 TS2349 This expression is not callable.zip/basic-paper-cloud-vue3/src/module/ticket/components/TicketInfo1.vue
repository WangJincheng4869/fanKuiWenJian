<script setup lang="ts">
import {ref} from "vue";

const v = ref('')
</script>

<template>
  <input v-model="v" placeholder="工单1">
</template>

<style scoped>

</style>