<script setup lang="ts">

</script>

<template>
  <router-link to="/ticket">工单</router-link>
  <input value="主页">
  <router-link to="/ticket1">工单1</router-link>
  <router-view v-slot="{ Component, route }">
    <template v-if="route.meta.keepAlive">
      <keep-alive>
        <component :is="Component" :key="route.name"/>
      </keep-alive>
    </template>
    <component v-else :is="Component" :key="route.name"/>
  </router-view>
</template>

<script>
export default {
  name: "Main"
}
</script>

<style scoped>

</style>