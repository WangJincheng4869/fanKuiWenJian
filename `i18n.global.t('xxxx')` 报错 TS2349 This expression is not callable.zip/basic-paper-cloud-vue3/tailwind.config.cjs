/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ['./index.html', './src/**/*.{vue,js}'],
  theme: {
    extend: {},
  },
  plugins: [],
  corePlugins: {
    // 禁用响应式容器功能，即container类
    container: false,
  }
}
