/**
 * @license Copyright (c) 2003-2022, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see https://ckeditor.com/legal/ckeditor-oss-license
 */

CKEDITOR.editorConfig = function( config ) {
	// Define changes to default configuration here. For example:
	// config.language = 'fr';
	// config.uiColor = '#AADC6E';
  config.toolbarGroups = [
    {name: 'document', groups: ['mode', 'document', 'doctools']},
    {name: 'clipboard', groups: ['clipboard', 'undo']},
    {name: 'editing', groups: ['find', 'selection', 'spellchecker', 'editing']},
    {name: 'forms', groups: ['forms']},
    {name: 'links', groups: ['links']},
    {name: 'insert', groups: ['insert']},
    {name: 'tools', groups: ['tools']},
    // {name: 'about', groups: ['about']},
    '/',
    {name: 'basicstyles', groups: ['basicstyles', 'cleanup']},
    {name: 'styles', groups: ['styles']},
    {name: 'paragraph', groups: ['list', 'indent', 'blocks', 'align', 'bidi', 'paragraph']},
    {name: 'colors', groups: ['colors']},
    {name: 'others', groups: ['others']}
  ];
  config.codeSnippet_theme = 'github-dark';
  config.language = 'zh-cn';
  config.allowedContent = true;
  config.colorButton_colors = 'c00000,ff0000,ffc000,ffff00,92d050,00b050,' +
    '00b0f0,0070c0,002060,7030a0,ffffff,000000,' +
    'ffffff,f2f2f2,d8d8d8,bfbfbf,a5a5a5,7f7f7f,' +
    '000000,7f7f7f,595959,3f3f3f,262626,0c0c0c,' +
    'e7e6e6,d0cece,aeabab,757070,3a3838,171616,' +
    '44546a,d6dce4,adb9ca,8496b0,323f4f,222a35,' +
    '4472c4,d9e2f3,b4c6e7,8eaadb,2f5496,1f3864,' +
    'ed7d31,fbe5d5,f7cbac,f4b183,c55a11,833c0b,' +
    'a5a5a5,ededed,dbdbdb,c9c9c9,7b7b7b,525252,' +
    'ffc000,fff2cc,fee599,ffd965,bf9000,7f6000,' +
    '5b9bd5,deebf6,bdd7ee,9cc3e5,2e75b5,1e4e79,' +
    '70ad47,e2efd9,c5e0b3,a8d08d,538135,375623'
};

/**
 * 设置超链接默认为新窗口方式(_blank)
 */
CKEDITOR.on('dialogDefinition', function(ev) {
  // Take the dialog name and its definition from the event
  // data.
  var dialogName = ev.data.name;
  var dialogDefinition = ev.data.definition;

  // Check if the definition is from the dialog we are
  // interested on (the "Link" dialog).
  if (dialogName === 'link') {
    // Get a reference to the "Target" tab.
    var targetTab = dialogDefinition.getContents('target');

    // Set the default value for the target field.
    var targetField = targetTab.get('linkTargetType');
    targetField['default'] = '_blank';
  }
});