<script setup lang="ts">


</script>

<template>
  <div class="sp-icon-item">
    <span class="sp-icon-name"></span>
  </div>
</template>

<style lang="scss" scoped>
.sp-icon-item {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  flex: 0 0 auto;
  cursor: pointer;
  color: var(--el-text-color-regular);
  height: 100px;
  width: 145px;
  font-size: 28px;
  margin-top: -1px;
  border-top: 1px solid var(--el-border-color);
  border-right: 1px solid var(--el-border-color);
  border-bottom: 1px solid var(--el-border-color);
  transition: background-color var(--el-transition-duration);

  &:hover {
    background-color: var(--el-border-color-extra-light);
    color: var(--el-text-color-primary);
  }

  .sp-icon-name {
    margin-top: 8px;
    font-size: 12px;
  }
}
</style>
