<script setup lang="ts">
import SpIconListItem from './SpIconListItem.vue';
import HelloWorld from '../../../../src/components/HelloWorld.vue';

</script>

<template>
  <div class="sp-icon-list">
      <sp-icon-list-item />
      <HelloWorld />
  </div>
</template>

<style lang="scss" scoped>
.sp-icon-list {
  overflow: hidden;
  display: flex;
  flex-wrap: wrap;
  padding-top: 1px;
  border-left: 1px solid var(--el-border-color);
}
</style>
