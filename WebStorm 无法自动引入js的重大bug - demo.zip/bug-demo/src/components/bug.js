const bug = () => {
  console.log('这就是个bug')
}

export {bug}