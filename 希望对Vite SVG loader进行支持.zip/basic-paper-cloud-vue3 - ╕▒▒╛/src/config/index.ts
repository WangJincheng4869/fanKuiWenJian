import axios from "axios";
import {useApplicationConfigStore} from "@/store/application-config";
import {urlUtils} from "@/util/http/url-utils";

/**
 * 将系统配置读取到状态管理中
 */
export const initApplicationConfig = async (): Promise<void> => {
  // 删除url地址结尾的/，无论有几个都会被删除
  let baseUrl = urlUtils.removeTrailingSlash(import.meta.env.BASE_URL)

  await axios.get(`${baseUrl}/application-config.json`)
      .then(({data}) => {
        let store = useApplicationConfigStore();
        store.$patch(data)
      }).catch(() => {
        throw '请在public文件夹下添加 application-config.json 配置文件';
      });
};
