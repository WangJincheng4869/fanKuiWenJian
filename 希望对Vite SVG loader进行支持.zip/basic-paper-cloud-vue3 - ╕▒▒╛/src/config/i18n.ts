// element-plus国际化
import enLocale from "element-plus/lib/locale/lang/en";
import zhLocale from "element-plus/lib/locale/lang/zh-cn";
import {createI18n, I18n, useI18n} from "vue-i18n";
import {Locale} from "@intlify/core-base";

// 切换语言使用的类型
export type SwitchI18nLang = 'zh-CN' | 'en' | Locale;

/**
 * 抽取多语言数据
 * @param prefix 多语言文件前缀，即语言类型
 */
function siphonI18n(prefix = "zh-CN") {
  const i18n: any = {};
  // 将所有多语言翻译内容读取出来，读取出来数据结构是一个对象。例：{'../../locale/zh-CN.yml': {}, '../../locale/en.yml': {}}
  let localeRecord: Record<string, any> = import.meta.glob("../../locale/*.yml", {eager: true});
  Object.keys(localeRecord).forEach(key => {
    // 将文件后缀去掉，作为多语言翻译存储的key
    const matched = key.match(/([A-Za-z0-9-_]+)\./i);
    if (matched) {
      // 如果提取成功，则数组内第二项为去除掉.yml的值
      let localeKey = matched[1]
      i18n[localeKey] = localeRecord[key].default;
    }
  });
  return i18n[prefix];
}

/**
 * 获取当前语言类型
 */
function getStorageLocale(): SwitchI18nLang {
  let locale = localStorage.getItem('locale');
  if (!locale) {
    return 'zh-CN'
  }
  switch (locale) {
    case 'en':
      return 'en'
    default:
      return 'zh-CN'
  }
}

/**
 * 全部多语言数据
 */
export const localesConfigs = {
  'zh-CN': {
    ...siphonI18n("zh-CN"),
    ...zhLocale
  },
  en: {
    ...siphonI18n("en"),
    ...enLocale
  }
};

/**
 * 初始化i18n组件
 */
export const i18n: I18n = createI18n({
  legacy: false,
  locale: getStorageLocale(),
  fallbackLocale: "zh-CN",
  messages: localesConfigs
});

/**
 * i18n工具类
 */
export function i18nUtils() {
  // useI18n必须写在setup中，故要写在这里，在setup中结构此方法，拿到switchI18n进行使用
  const {locale, t} = useI18n();
  // 全部支持的语言类型
  const locales = {
    'zh-CN': t('locale.simplifiedChinese'),
    'en': t('locale.english')
  }
  /**
   * 语言切换
   * @param lang 支持字符串 zh-CN、en
   */
  const switchI18n = (lang: SwitchI18nLang = "zh-CN") => {
    if (Object.keys(locales).indexOf(lang) > -1) {
      locale.value = lang
      localStorage.setItem('locale', lang);
      document.querySelector('html')?.setAttribute('lang', lang)
    } else {
      console.warn(`切换的语言不支持，默认切换为中文 lang=${lang}`)
      locale.value = 'zh-CN'
      localStorage.setItem('locale', 'zh-CN');
      document.querySelector('html')?.setAttribute('lang', 'zh-CN')
    }
  }

  /**
   * 获取当前语言类型
   */
  function getLocale(): SwitchI18nLang {
    return locale.value;
  }

  return {switchI18n, getLocale, locales}
}