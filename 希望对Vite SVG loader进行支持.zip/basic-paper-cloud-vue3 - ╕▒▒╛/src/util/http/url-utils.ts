class UrlUtils {

  private static readonly TRAILING_SLASH_RE = /\/*$/;

  /**
   * 删除url地址结尾的/，无论有几个都会被删除
   * @param url
   */
  public removeTrailingSlash(url: string): string {
    if (url) {
      return url.replace(UrlUtils.TRAILING_SLASH_RE, '');
    }
    return ''
  }
}

export const urlUtils = new UrlUtils();