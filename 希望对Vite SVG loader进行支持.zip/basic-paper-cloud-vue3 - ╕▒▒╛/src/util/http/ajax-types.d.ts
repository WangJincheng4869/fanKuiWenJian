/**
 * api接口返回统一类型
 */
export interface ResultVO {
  /**
   * 请求状态码
   */
  status: number;
  /**
   * 返回消息
   */
  msg: string;
  /**
   * 异常消息
   */
  errMsg: string;
  /**
   * 返回的数据
   */
  data: any;
}