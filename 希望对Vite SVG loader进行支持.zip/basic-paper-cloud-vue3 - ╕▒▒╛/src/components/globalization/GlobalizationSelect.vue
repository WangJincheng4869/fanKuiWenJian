<script setup lang="ts">
import globalization from "@/assets/svg/globalization.svg?component"
</script>

<template>
  <globalization class="w-5 h-5 hover:text-primary" />
</template>

<style scoped lang="scss">

</style>