# 简介

本项目使用了 Vue 3、TypeScript 和 Vite。 需要使用 Vue 3 `<script setup>` 进行开发, 查看 [script setup 文档](https://cn.vuejs.org/api/sfc-script-setup.html) 了解更多内容。

本项目包管理工具使用的是 [pnpm](https://pnpm.io/zh/)，如果没有则需要先安装`pnpm`环境。安装 pnpm 环境之前，你还要安装 nodejs 环境才能正常工作（这里默认你熟悉nodejs）。

## 项目初始化与启动

### 安装 pnpm 并进行相关配置

通过 npm 安装 pnpm

```shell
npm install -g pnpm
```

修改存储路径

```shell
pnpm config set store-dir D:\Users\jcwang\AppData\Roaming\pnpm-store
```

修改缓存路径

```shell
pnpm config set cache-dir D:\Users\jcwang\AppData\Roaming\pnpm-cache
```

修改全局安装包的 bin 文件的目标目录，并将`D:\Users\jcwang\AppData\Roaming\pnpm`配置到环境变量的`Path`中

```shell
pnpm config set global-bin-dir D:\Users\jcwang\AppData\Roaming\pnpm
```

指定用于存储全局包的目录

```shell
pnpm config set global-dir D:\Users\jcwang\AppData\Roaming\pnpm\global
```

### 初始化项目

```shell
pnpm install
```

### 启动项目

```shell
pnpm dev
```

默认访问端口为`5173`，但为了方便开发，请使用`Nginx`配置代理，详见开发文档的`快速上手`部分

## 查看开发文档

启动文档命令

```shell
pnpm docs:dev
```

启动成功后访问 [http://localhost:5174/basic-paper-cloud-docs/]( http://localhost:5174/basic-paper-cloud-docs/) 查看文档