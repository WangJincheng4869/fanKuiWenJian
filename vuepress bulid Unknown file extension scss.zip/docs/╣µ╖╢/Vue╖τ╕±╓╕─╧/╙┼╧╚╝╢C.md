---
title: 优先级 C 的规则：推荐
author: 王金城
---

## 元素 attribute 的顺序

元素 (包括组件) 的 attribute 应该有统一的顺序。

这是我们为组件选项推荐的默认顺序。它们被划分为几大类，所以你也能知道新添加的自定义 attribute 和指令应该放到哪里。

1. 定义 (提供组件的选项)
    * `is`
2. 列表渲染 (创建多个变化的相同元素)
    * `v-for`
3. 条件渲染 (元素是否渲染/显示)
    * `v-if`
    * `v-else-if`
    * `v-else`
    * `v-show`
    * `v-cloak`
4. 渲染方式 (改变元素的渲染方式)
    * `v-pre`
    * `v-once`
5. 全局感知 (需要超越组件的知识)
    * `id`
6. 唯一的 attribute (需要唯一值的 attribute)
    * `ref`
    * `key`
7. 双向绑定 (把绑定和事件结合起来)
    * `v-model`
8. 其它 attribute (所有普通的绑定或未绑定的 attribute)
9. 事件 (组件事件监听器)
    * `v-on`
10. 内容 (覆写元素的内容)
    * `v-html`
    * `v-text`

## 单文件组件的顶级元素的顺序

单文件组件应该总是让 `<script>`、`<template>` 和 `<style>` 标签的顺序保持一致。且 `<style>` 要放在最后，因为另外两个标签至少要有一个。

> 正例：
> ```vue
> <!-- ComponentA.vue -->
> <script setup>/* ... */</script>
> <template>...</template>
> <style scoped>/* ... */</style>
> ```