import { SidebarOptions } from "vuepress-theme-hope";

// 侧边栏配置 https://theme-hope.vuejs.press/zh/guide/layout/sidebar.html
export const sidebar: SidebarOptions = {
  '/guide/': [
    'intro.md', // 介绍
    {
      text: '开发环境',
      prefix: "dev-env",
      children: [
        'nginx.md', // 开发环境安装介绍
        'web.md', // 前端依赖环境
      ],
    },
    {
      text: '目录结构',
      prefix: "directory-structure/",
      children: [
        'web.md', // 目录结构介绍
      ],
    },
    {
      text: '配置文件',
      prefix: 'config/',
      children: [
        'web.md', // 前端项目配置
      ],
    },
    {
      text: '基础',
      prefix: 'basics/',
      children: [
        'router.md', // 路由和菜单介绍
        'http.md', // http 请求介绍
        'theme.md', // 主题和暗黑模式
        'i18n.md', // 国际化
        '图标.md',
        'store.md',
      ],
    },
  ],
  '/component/': [],
  '/api/': [],
  '/规范/': [
    {
      text: '编程规约',
      prefix: '编程规约/',
      children: [
        '命名风格.md',
        '常量定义.md',
        '代码格式.md',
      ]
    },
    {
      text: 'Vue 风格指南',
      prefix: 'Vue风格指南/',
      children: [
        '规则归类.md',
        '优先级A.md',
        '优先级B.md',
        '优先级C.md',
        '优先级D.md',
      ]
    }
  ],
}
