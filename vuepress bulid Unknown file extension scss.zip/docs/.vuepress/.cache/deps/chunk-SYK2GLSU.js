// node_modules/.pnpm/element-plus@2.3.3_vue@3.2.47/node_modules/element-plus/es/components/base/style/index.mjs
import "D:/Web Workspace/CODE_Develop/Service_Products/BasicPaper/webCode/basic-paper-cloud-vue3/node_modules/.pnpm/element-plus@2.3.3_vue@3.2.47/node_modules/element-plus/theme-chalk/src/base.scss";
//# sourceMappingURL=chunk-SYK2GLSU.js.map
