import "./chunk-SYK2GLSU.js";
//# sourceMappingURL=element-plus_es_components_base_style_index.js.map
