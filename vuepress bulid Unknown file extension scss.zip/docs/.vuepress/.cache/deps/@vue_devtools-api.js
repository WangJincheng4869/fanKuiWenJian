import {
  isPerformanceSupported,
  now,
  setupDevtoolsPlugin
} from "./chunk-Z6EPN34Q.js";
import "./chunk-DFKQJ226.js";
export {
  isPerformanceSupported,
  now,
  setupDevtoolsPlugin
};
//# sourceMappingURL=@vue_devtools-api.js.map
