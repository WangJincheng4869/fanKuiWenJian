import "./chunk-SYK2GLSU.js";

// node_modules/.pnpm/element-plus@2.3.3_vue@3.2.47/node_modules/element-plus/es/components/badge/style/index.mjs
import "D:/Web Workspace/CODE_Develop/Service_Products/BasicPaper/webCode/basic-paper-cloud-vue3/node_modules/.pnpm/element-plus@2.3.3_vue@3.2.47/node_modules/element-plus/theme-chalk/src/badge.scss";

// node_modules/.pnpm/element-plus@2.3.3_vue@3.2.47/node_modules/element-plus/es/components/message/style/index.mjs
import "D:/Web Workspace/CODE_Develop/Service_Products/BasicPaper/webCode/basic-paper-cloud-vue3/node_modules/.pnpm/element-plus@2.3.3_vue@3.2.47/node_modules/element-plus/theme-chalk/src/message.scss";
//# sourceMappingURL=element-plus_es_components_message_style_index.js.map
