// node_modules/.pnpm/element-plus@2.3.3_vue@3.2.47/node_modules/element-plus/es/components/base/style/css.mjs
import "D:/Web Workspace/CODE_Develop/Service_Products/BasicPaper/webCode/basic-paper-cloud-vue3/node_modules/.pnpm/element-plus@2.3.3_vue@3.2.47/node_modules/element-plus/theme-chalk/base.css";
//# sourceMappingURL=chunk-WQT4F5MI.js.map
