<script setup lang="ts">
import SpIcon from "../../../../src/components/icon/SpIcon.vue";
import { defineProps } from "vue"
import { SpIconName } from "../../../../src/components/icon/types";
import { useClipboard } from "@vueuse/core";
import { msgUtils } from "@/util/feedback/msg-utils"

interface Props {
  name: SpIconName
}

const props = defineProps<Props>()

const {copy} = useClipboard()

const copyName = () => {
  copy(`<sp-icon name="${props.name}"/>`).then(() => {
    msgUtils.success('已复制！')
  })
}
</script>

<template>
  <div class="sp-icon-item" @click="copyName">
    <sp-icon :name="props.name"/>
    <span class="sp-icon-name">{{ props.name }}</span>
  </div>
</template>

<style lang="scss" scoped>
.sp-icon-item {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  flex-grow: 1;
  cursor: pointer;
  color: var(--el-text-color-regular);
  height: 100px;
  width: 140px;
  font-size: 28px;
  border-right: 1px solid var(--el-border-color);
  border-bottom: 1px solid var(--el-border-color);
  transition: background-color var(--el-transition-duration);

  &:hover {
    background-color: var(--el-border-color-extra-light);
    color: var(--el-text-color-primary);
  }

  .sp-icon-name {
    margin-top: 8px;
    font-size: 12px;
  }
}
</style>