<script setup lang="ts">
import SpIconListItem from "./SpIconListItem.vue";
import { SpIconName } from "../../../../src/components/icon/types";

const systemIconNames: SpIconName[] = [
  'application',
  'arrow-down',
  'clock',
  'close',
  'customer',
  'home',
  'kb',
  'language',
  'message',
  'monitor',
  'moon-fat-filled',
  'normal',
  'notification',
  'plus-square',
  'report',
  'search',
  'setting',
  'sms',
  'soft-phone',
  'sunny-filled',
  'suona-multi',
  'ticket-clock-multi',
  'ticket-completed-multi',
  'ticket-create-multi',
  'ticket-submit-multi',
  'ticket-user-multi',
  'tickets',
  'tips',
  'unknown-animate',
  'work'
]
</script>

<template>
  <div class="sp-icon-list">
    <template v-for="name in systemIconNames">
      <sp-icon-list-item :name="name"/>
    </template>
  </div>
</template>

<style lang="scss" scoped>
.sp-icon-list {
  overflow: hidden;
  display: flex;
  flex-wrap: wrap;
  border-top: 1px solid var(--el-border-color);
  border-left: 1px solid var(--el-border-color);
}
</style>