import { defineUserConfig, viteBundler } from "vuepress";
import { hopeTheme } from "vuepress-theme-hope";
import { sidebar } from "./configs/sidebar";
import { navbar } from "./configs/navbar";
import { registerComponentsPlugin } from '@vuepress/plugin-register-components'
import { resolve } from "path";
import svgLoader from "vite-svg-loader";
import VueI18nPlugin from "@intlify/unplugin-vue-i18n/vite";
import { searchProPlugin } from "vuepress-plugin-search-pro";
import AutoImport from "unplugin-auto-import/vite";
import Components from "unplugin-vue-components/vite";
import { ElementPlusResolver } from "unplugin-vue-components/resolvers";

export default defineUserConfig({
  host: "0.0.0.0",
  port: 5174,
  base: "/basic-paper-cloud-docs/",
  lang: "zh-CN",
  title: "BasicPaperCloud",
  description: "BasicPaperCloud 前后端分离开发文档",
  alias: {
    "@": resolve(__dirname, "../../src"),
  },
  bundler: viteBundler({
    viteOptions: {
      css: {
        preprocessorOptions: {
          scss: {
            additionalData: `@use "@/styles/element/index.scss" as *;`,
          },
        },
      },
      plugins: [
        // https://github.com/jpkleemans/vite-svg-loader
        svgLoader(),
        // https://github.com/antfu/unplugin-auto-import
        AutoImport({
          imports: [
            'vue',
          ],
          dirs: [
            'src/util/**',
            'src/hooks/**',
          ],
          dts: 'types/auto-imports.d.ts',
          cache: 'unplugin-auto-import.json',
          resolvers: [
            ElementPlusResolver({
              importStyle: "sass",
            }),
          ],
        }),
        // https://github.com/antfu/unplugin-vue-components
        Components({
          // 只用ElementPlus的按需导入，故不扫描自己的项目文件
          dirs: [],
          dts: "types/components.d.ts",
          resolvers: [
            ElementPlusResolver({
              importStyle: "sass",
            }),
          ],
        }),
        // https://github.com/intlify/bundle-tools/tree/main/packages/vite-plugin-vue-i18n
        VueI18nPlugin({
          runtimeOnly: true,
          compositionOnly: true,
          include: [resolve(__dirname, "../../locales/**")],
        }),
      ],
      ssr: {
        /**
         * 由于在 build 时会报错 SyntaxError: Named export 'createI18n' not found.
         * The requested module 'vue-i18n/dist/vue-i18n.runtime.esm-bundler.js' is a CommonJS module, which may not support all module.exports as named exports.
         * 所以要添加以下配置。详见：https://vite-plugin-ssr.com/common-issues 与 https://vite-plugin-ssr.com/invalid-esm#solution
         */
        noExternal: ['vue-i18n']
      }
    }
  }),
  theme: hopeTheme({
    navbar: navbar,
    sidebar: sidebar,
    lastUpdated: true,
    plugins: {
      copyCode: {
        showInMobile: true
      },
      autoCatalog: true,
    }
  }),
  plugins: [
    searchProPlugin({
      queryHistoryCount: 8,
      resultHistoryCount: 8,
      locales: {
        '/': {
          placeholder: '搜索文档',
          search: '搜索文档',
        }
      }
    }),
    // 根据组件文件或目录自动注册 Vue 组件 https://v2.vuepress.vuejs.org/zh/reference/plugin/register-components.html
    registerComponentsPlugin({
      componentsDir: resolve(__dirname, '../../src/components'),
    })
  ],
});
