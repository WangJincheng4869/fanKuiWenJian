import { defineClientConfig } from '@vuepress/client'
import ElementPlus from 'element-plus'
import { i18n } from "@/config/i18n";
// import './styles/element/index.scss'
import SpIconList from "./components/sp-icon-list/SpIconList.vue";
import { useColorMode } from "@vueuse/core";

export default defineClientConfig({
  enhance({app}) {
    app.use(ElementPlus).use(i18n).component('SpIconList', SpIconList)

    // 其实主题绑定 class，让切换主题时能给 class 添加对应的主题色样式，因为 vuepress 默认为 data-theme
    useColorMode({
      storageKey: 'vuepress-theme-hope-scheme',
    });
  },
})