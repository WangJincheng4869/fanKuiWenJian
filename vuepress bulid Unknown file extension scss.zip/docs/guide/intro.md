---
title: 介绍
author: 王金城
---

* BasicPaperCloud
是新一代的业务系统框架，使用 [Spring Cloud](https://spring.io/projects/spring-cloud)、[TypeScript](https://www.tslang.cn/index.html)、[Sass](https://www.sass.hk/)、[Vite](https://cn.vitejs.dev/)、[Vue 3](https://cn.vuejs.org/)、[Element Plus](https://element-plus.org/zh-CN/)、[Pinia](https://pinia.vuejs.org/zh/)、[Tailwindcss](https://www.tailwindcss.cn/)
等主流技术栈开发。

* 支持全球化多语言切换与快捷开发。

* 支持主题切换功能（目前仅支持深色、浅色模式，并支持根据系统设置自动识别切换）。

* 此文档使用 [vuepress 2](https://v2.vuepress.vuejs.org/zh/) 开发，采用 [VuePress Theme Hope](https://theme-hope.vuejs.press/zh/) 主题。

## 前端技术栈

- [pnpm](https://pnpm.io/zh/)
- [TypeScript](https://www.tslang.cn/index.html)
- [Sass](https://www.sass.hk/)
- [Vite](https://cn.vitejs.dev/)
- [Vue3](https://cn.vuejs.org/)
- [Element Plus](https://element-plus.org/zh-CN/)
- [Vue Router](https://router.vuejs.org/zh/)
- [Vue I18n](https://vue-i18n.intlify.dev/)
- [VueUse](https://vueuse.org/)
- [Pinia](https://pinia.vuejs.org/zh/)
- [Tailwindcss](https://www.tailwindcss.cn/)
- [Axios](https://www.axios-http.cn/docs/intro)

## 后端技术栈

- [Spring Cloud](https://spring.io/projects/spring-cloud)
- [Spring Cloud Alibaba](https://spring.io/projects/spring-cloud-alibaba)
- [Spring Cloud Gateway](https://spring.io/projects/spring-cloud-gateway)
- [Nacos](https://nacos.io/zh-cn/)
