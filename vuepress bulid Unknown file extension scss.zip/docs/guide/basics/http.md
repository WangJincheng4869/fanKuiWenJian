---
title: 前端 http 请求
author: 王金城
---

前端平台对 [Axios](https://www.axios-http.cn/) 进行了封装，支持的请求方式与高级使用方法请看 [Axios API](https://www.axios-http.cn/docs/api_intro)。

## 实现自己模块的工具类

由于 `axios` 需要设置 `baseURL`。但是不同的模块的 `baseURL` 可能不同。所以为了方便使用，框架中封装了一个类 `AjaxUtils`，在 `src/util/http/ajax-utils.ts` 中。需要创建实例实现各自模块的工具类，下面以创建单点登录的工具类为例

```ts
/**
 * 单点登录模块 Ajax 工具类
 */
const ajaxSso = new AjaxUtils({
  baseURL: apiBaseUrl.sso,
});

export { ajax, ajaxSso };
```

## 使用工具类

::: tip
你无需纠结 `baseURL` 结尾是否需要有 `/`，也无需纠结 `url` 开头是否有 `/`，因为 axios 内部会分别去除 `baseURL` 结尾的 `/` 和 `url` 开头的 `/` 再进行拼接，源码如下

```js
/**
 * Creates a new URL by combining the specified URLs
 *
 * @param {string} baseURL The base URL
 * @param {string} relativeURL The relative URL
 *
 * @returns {string} The combined URL
 */
export default function combineURLs(baseURL, relativeURL) {
  return relativeURL
    ? baseURL.replace(/\/+$/, '') + '/' + relativeURL.replace(/^\/+/, '')
    : baseURL;
}

```
:::

我们以最常用的`postRawJson`方法为例

```ts
ajaxSso.postRawJson<void>(`sso_auth/login`, {
  username: 'username',
  password: 'password',
}).then(result => {
  if (result.status === ResultStatusEnum.SUCCESS) {
    // 这里写请求成功的操作
  } else if (result.status === ResultStatusEnum.ERROR_SYSTEM) {
    msgUtils.error(result.msg)
  } else {
    msgUtils.warning(result.msg)
  }
}).catch(() => {
// 这里可以自定义你的异常处理
})
```
