---
title: 存储
author: 王金城
---

## 状态管理

状态管理我们使用 [Pinia](https://pinia.vuejs.org/zh/)，它是 Vue3
推荐使用的状态管理库。你不能随意的使用它们，要遵循一定的规则，首先你要了解 [Pinia（状态管理）的命名规则](../../规范/Vue风格指南/优先级B.md#pinia状态管理的命名)

您现在已经了解了该如何[命名](../../规范/Vue风格指南/优先级B.md#pinia状态管理的命名)，但还要注意一下几点：

1. 子模块专用的状态管理需要放在模块目录下
   > 正例：
   > `src/module/sso/store/`
2. 全项目通用的状态管理放在 `src/store` 目录下
3. 状态管理的 ID 统一维护在 `/src/constant/store-id-consts.ts` 中（为了防止 ID 重复）
4. 统一使用 [Setup Store](https://pinia.vuejs.org/zh/core-concepts/#setup-stores)模式来定义

## SessionStorage

在项目中 SessionStorage 是比较常用的一种存储方式，这里我们推荐使用 VueUse 中的 [useSessionStorage](https://vueuse.org/core/useSessionStorage/)，它会简化您的操作。

为了防止 SessionStorage 的 Key 冲突导致未知的问题，我们需要将全部的 Key 统一维护在 `/src/constant/session-storage-key-consts.ts` 中。

::: tip
SessionStorage 是本标签生效，在 `index.html` 写了复制到新标签页的方法，如果你也需要将值复制到新标签页，请将要复制的 key 添加到 `copeKeys` 数组中
:::

## LocalStorage

在项目中 LocalStorage 是比较常用的一种存储方式，这里我们推荐使用 VueUse 中的 [useLocalStorage](https://vueuse.org/core/useLocalStorage/)，它会简化您的操作。

为了防止 LocalStorage 的 Key 冲突导致未知的问题，我们需要将全部的 Key 统一维护在 `/src/constant/local-storage-key-consts.ts` 中。