---
title: Nginx 安装与配置
author: 王金城
---

前后端分离开发需要同时启动前端服务和后端服务，那么会出现端口不同导致跨域访问的问题，我们需要使用 Nginx 做代理，消除跨域问题。

## window 安装 Nginx 并注册为服务

1. 下载稳定版本（Stable version）的 [Nginx](https://nginx.org/en/download.html)，我把他解压到了`D:\Users\jcwang\Apps`目录下，你可以根据自己的使用习惯来修改
2. 下载 [WinSW](https://github.com/winsw/winsw/releases)，根据自己的系统选择，一般都是选择`WinSW-x64.exe`
3. 修改文件名为`nginx-service.exe`放入`nginx.exe`所在目录
4. 在nginx目录下创建`nginx-service.xml`，与`nginx-service.exe`文件名相同

```xml
<service>
    <id>nginx</id>
    <name>nginx</name>
    <description>nginx</description>
    <logpath>D:\Users\jcwang\Apps\nginx-1.21.4\logs</logpath>
    <log mode="roll"></log>
    <depend></depend>
    <executable>D:\Users\jcwang\Apps\nginx-1.21.4\nginx.exe</executable>
    <stopexecutable>D:\Users\jcwang\Apps\nginx-1.21.4\nginx.exe -s stop</stopexecutable>
</service>
```

5. 执行`nginx-service.exe install`安装服务

### 配置开发环境代理

1. 在`Nginx`安装目录下找到`conf`文件夹
2. 在`conf`目录下创建`proxy.conf`。这是一个通用配置文件，复制以下内容写入文件中。

```nginx
#Websocket需要下面三行
proxy_http_version 1.1;
proxy_set_header Upgrade $http_upgrade;
proxy_set_header Connection "upgrade";
#后端的Web服务器可以通过X-Real-IP获取用户真实IP
proxy_set_header X-Real-IP $remote_addr;
#后端的Web服务器可以通过X-Forwarded-For获取用户真实IP
proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
proxy_set_header Host $host;
#允许客户端请求的最大单文件字节数
client_max_body_size 10m;
```

3. 在`80`端口的`server`下加入`/basic-paper-cloud`和`/basic-paper-cloud/api/`代理，配置样例如下：

```nginx {6-9,11-14}
http {
  server {
    listen 80;
    server_name localhost;

    location /basic-paper-cloud {
      proxy_pass http://localhost:5173/basic-paper-cloud;
      include proxy.conf;
    }

    location /basic-paper-cloud/api/ {
      proxy_pass http://localhost:8000/;
      include proxy.conf;
    }
  }
}
```

4. 配置完成后，到`Windows`启动服务中启动`nginx`服务