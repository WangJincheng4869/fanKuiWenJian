---
title: 前端依赖环境
author: 王金城
---

- [Node.js 18.14.0+](https://nodejs.org/)
- [pnpm 8+](https://pnpm.io/zh/)

## Window 开发环境安装

### 安装 nodejs

在 nodejs 官网下载最新的 LTS（长期维护版）版本 [https://nodejs.org/zh-cn/](https://nodejs.org/zh-cn/)，一直选下一步进行安装即可

::: tip
如果您在使用 [PowerShell](https://learn.microsoft.com/zh-cn/powershell/) 的话，当执行 `npm` 命令时可能会报错 `此系统禁止运行脚本`
，这时需要修改 [PowerShell 执行策略](https://learn.microsoft.com/zh-cn/powershell/module/microsoft.powershell.core/about/about_execution_policies?view=powershell-7.3)，需要使用管理员运行
PowerShell 后执行以下命令：

```shell
Set-ExecutionPolicy -ExecutionPolicy RemoteSigned
```

:::

### 修改 npm 的配置

查看配置

```shell
npm config ls
```

修改全局包下载存放位置，并将 `D:\Users\jcwang\AppData\Roaming\npm` 配置到环境变量的 `Path` 中

```shell
npm config set prefix "D:\Users\jcwang\AppData\Roaming\npm"
```

修改 node 缓存的位置

```shell
npm config set cache "D:\Users\jcwang\AppData\Roaming\npmCache"
```

修改 npm 镜像，使用 `公司公网私服`

```shell
# 公司公网私服（使用这配置）
npm config set registry https://wxspirit.simperfect.com/repository/npm-group/
# 国内镜像地址（备用，无需执行）
npm config set registry https://registry.npmmirror.com
# 公司内网私服映射（备用，无需执行）
npm config set registry http://172.28.168.186:8081/repository/npm-group/
```

使用公网私服镜像，可能出现配置镜像失败的问题，如：虽然配置的域名，但是执行 `npm info express` 后发现 `.tarball` 为私网地址 `172.28.168.186:8081`，可执行以下命令清除缓存

```shell
npm cache clean --force
```

### 安装 [pnpm](https://pnpm.io/zh/) 并进行相关配置

通过 npm 安装

```shell
npm install -g pnpm
```

修改存储路径

```shell
pnpm config set store-dir D:\Users\jcwang\AppData\Roaming\pnpm-store
```

修改缓存路径

```shell
pnpm config set cache-dir D:\Users\jcwang\AppData\Roaming\pnpm-cache
```

修改全局安装包的 bin 文件的目标目录，并将 `D:\Users\jcwang\AppData\Roaming\pnpm` 配置到环境变量的 `Path` 中

```shell
pnpm config set global-bin-dir D:\Users\jcwang\AppData\Roaming\pnpm
```

指定用于存储全局包的目录

```shell
pnpm config set global-dir D:\Users\jcwang\AppData\Roaming\pnpm\global
```

## IDE

这里不强制要求使用哪种编辑器，主要看自己的使用习惯。我主要体验了 [WebStorm](https://www.jetbrains.com/zh-cn/webstorm/) 和 [VS Code](https://code.visualstudio.com/) 两种编辑器，可以说是各有千秋。
我在 [VS Code](https://code.visualstudio.com/) 编辑器的配置上也花费了不少的时间，已经将配置整合到项目中，感兴趣的同学可以尝试一下（虽然我已经被劝退了）。

功能比较

| 功能        | WebStorm                      | VS Code                      |
|-----------|-------------------------------|------------------------------|
| 完全免费      | :x:                           | :heavy_check_mark:           |
| 设置云同步     | :heavy_check_mark: 仅订阅用户可用    | :heavy_check_mark:           |
| 开箱即用      | :heavy_check_mark:            | :x:                          |
| 智能提示      | :heavy_check_mark:            | :x:                          |
| i18n Ally | :heavy_check_mark: 部分情况无法显示文字 | :heavy_check_mark:           |
| 导入提示      | :heavy_check_mark:            | :heavy_check_mark: 部分情况下会失效  |
| 版本管理      | :heavy_check_mark:            | :heavy_check_mark: 对SVN的支持较差 |

### VS Code

您可以使用 [VS Code](https://code.visualstudio.com/) 进行开发工作，项目中也内置了推荐安装的插件，在 `.vscode` 目录下。

优缺点对比：

| 优点               | 缺点          |
|------------------|-------------|
| 完全免费             | 需要繁琐的配置才能使用 |
| 设置云同步            | 没有智能提示功能    |
| i18n Ally 插件功能完善 | 导入提示不够完善    |
| 外观好看一些，图标主题丰富    | 对SVN的支持较差   |

### WebStorm

您也可以使用 [WebStorm](https://www.jetbrains.com/zh-cn/webstorm/) 进行开发工作，他比 `VS Code` 更加智能，且对于用惯了 `IDEA` 的开发者来说几乎是0学习成本。

优缺点对比：

| 优点                 | 缺点                            |
|--------------------|-------------------------------|
| 拥有智能提示功能，可大大增加开发效率 | 付费软件，且还比较贵                    |
| 设置云同步（如果是订阅用户）     | 无设置云同步（非订阅用户）                 |
| 开箱即用，几乎不用修改配置      | i18n Ally 插件功能有瑕疵，部分情况下无法显示文本 |
| 对SVN的支持非常好         | 要使用最新版本开发，否则对前端支持不佳           |

## 开发常用命令

### 安装项目所有依赖

```shell
pnpm install
```

### 启动项目

```shell
pnpm dev
```

### 启动项目中的文档模块

```shell
pnpm docs:dev
```

### 安装新的软件包

安装软件包及其依赖的任何软件包。 默认情况下，任何新软件包都安装为生产依赖项。

```shell
pnpm add <pkg>
```

摘要：

| Command              | Meaning                  |
|----------------------|--------------------------|
| `pnpm add sax`       | 保存到 dependencies         |
| `pnpm add -D sax`    | 保存到 devDependencies      |
| `pnpm add -O sax`    | 保存到 optionalDependencies |
| `pnpm add -g sax`    | Install package globally |
| `pnpm add sax@next`  | 从 next 标签下安装             |
| `pnpm add sax@3.0.0` | 安装指定版本 3.0.0             |

### 更新软件包版本

在不带参数的情况下使用时，将更新所有依赖关系。

```shell
pnpm update
```

摘要：

| Command               | Meaning                           |
|-----------------------|-----------------------------------|
| `pnpm up`             | 遵循 package.json 指定的范围更新所有的依赖项     |
| `pnpm up --latest`    | 更新所有依赖项，此操作会忽略 package.json 指定的范围 |
| `pnpm up foo@2`       | 将 foo 更新到 v2 上的最新版本               |
| `pnpm up "@babel/\*"` | 更新 @babel 范围内的所有依赖项               |

### 删除软件包

别名: `rm`, `uninstall`, `un`

从 `node_modules` 和项目的 `package.json` 中删除相关 `packages`。

```shell
pnpm remove
```

#### 配置项

##### --recursive, -r

当在 工作区 中使用此命令时，将从每个工作区的包中移除相关依赖(或 多个依赖)。

当不在工作区内使用时，将删除相关依赖项 (或多个依赖), 也包含子目录中对应的包 。

##### --global, -g

从全局删除一个依赖包。

##### --save-dev, -D

仅删除开发环境 devDependencies 中的依赖项。

##### --save-optional, -O

仅移除 optionalDependencies 中的依赖项。

##### --save-prod, -P

仅从 dependencies 中删除相关依赖项。

##### --filter <package_selector>

## 访问前端页面

由于为了解决跨域问题，我们已经使用 `Nginx` 做了代理，所以我们访问的项目地址为 [http://localhost/basic-paper-cloud/](http://localhost/basic-paper-cloud/)