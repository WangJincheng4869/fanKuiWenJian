import {ApiBaseUrl} from "@/config/application-config-types"

declare global {
  export const apiBaseUrl: ApiBaseUrl
}