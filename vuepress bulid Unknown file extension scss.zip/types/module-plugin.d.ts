import 'vue-router'
import { TargetEnum } from "@/router/types";

declare module 'vue-router' {
  interface RouteMeta {
    /**
     * 是否保活，不配置则默认保活
     */
    offKeepAlive?: boolean
    /**
     * 不在系统的 tab 中打开，不配置则打开tab
     */
    target: TargetEnum
    /**
     * 是否关闭身份验证，不配置则默认需要验证
     */
    offAuth?: boolean
    /**
     * 打开tab的名称，如果需要打开tab，那么此项必填
     */
    title?: string
    /**
     * 权限控制，只有有此技能的用户才能访问此链接，如果为null则代表所有人均可用访问
     */
    skillCode?: string
  }
}