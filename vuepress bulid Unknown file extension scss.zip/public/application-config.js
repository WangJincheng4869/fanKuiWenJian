/**
 * 接口地址
 */
const apiBaseUrl = {
  // BP主模块
  bp: '/basic-paper-cloud/api/basic-paper-bp',
  // 登录模块
  sso: '/basic-paper-cloud/api/basic-paper-sso',
  // 配置模块
  config: '/basic-paper-cloud/api/basic-paper-config'
};