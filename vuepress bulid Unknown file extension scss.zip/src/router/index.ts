import { createRouter, createWebHistory, RouteRecordRaw } from 'vue-router';
import { useAuthStore } from "@/store/auth";
import nProgress from "nprogress";
import 'nprogress/nprogress.css';
import { useLayoutTabs } from "@/layout/hooks/use-layout-tabs";
import { i18n } from "@/config/i18n";
import { TargetEnum } from "@/router/types";
import { useUser } from "@/layout/hooks/use-user";

const {t} = i18n.global

// 读取系统全部的子路由
let modulesChildrenRouteRecord: Record<string, any> = import.meta.glob(['../module/**/router/children-*.ts'], {eager: true});
// 子路由集合
const childrenRoutes: RouteRecordRaw[] = [{
  path: '/home',
  name: 'home',
  component: () => import('@/layout/components/home/Home.vue'),
  meta: {
    title: t('menu.home'),
    target: TargetEnum.FIRST_TAB
  }
}];

// 子路由页面导入，需要在框架内部打开的路由页面
Object.keys(modulesChildrenRouteRecord).forEach(key => {
  let routes: RouteRecordRaw[] = modulesChildrenRouteRecord[key].default;
  routes.forEach((route) => {
    childrenRoutes.push(route)
  })
});

// 路由配置
const routes: RouteRecordRaw[] = [
  {
    path: '/',
    name: 'mainPage',
    component: () => import('@/layout/components/Main.vue'),
    redirect: {name: 'home'},
    children: childrenRoutes,
  }, {
    path: '/login',
    name: 'loginPage',
    component: () => import('@/module/sso/components/login/Login.vue'),
    meta: {
      offKeepAlive: true,
      target: TargetEnum._SELF,
      offAuth: true
    }
  }, {
    path: '/404',
    name: '404',
    component: () => import('@/layout/components/error/404.vue'),
    meta: {
      offKeepAlive: true,
      target: TargetEnum._SELF,
      offAuth: true
    }
  }, {
    path: '/403',
    name: '403',
    component: () => import('@/layout/components/error/403.vue'),
    meta: {
      offKeepAlive: true,
      target: TargetEnum._SELF,
      offAuth: true
    }
  }
]

let modulesRouteRecord: Record<string, any> = import.meta.glob(['../module/**/router/index.ts'], {eager: true});
// 模块主路由添加，不需要在内部打开，需要全屏打开的页面。例如：登录页
Object.keys(modulesRouteRecord).forEach(key => {
  let modulesRoutes: RouteRecordRaw[] = modulesRouteRecord[key].default;
  modulesRoutes.forEach((route) => {
    routes.push(route)
  })
});

const router = createRouter({
  history: createWebHistory(import.meta.env.BASE_URL),
  routes,
})

router.beforeEach(async (to) => {
  const name = to.name;
  if (!name) {
    return {name: '404'}
  }
  const skillCode = to.meta.skillCode;
  // 需要进行权限控制
  if (skillCode && !useUser.hasAuth(skillCode)) {
    return {name: '403'}
  }
  nProgress.start();
  switch (to.meta.target) {
    // 判断是否需要打开 tab
    case TargetEnum.NEW_TAB:
      const tab = useLayoutTabs.getTabByRouterName(name);
      // 如果tab已经存在，则选中当前tab
      if (tab) {
        const index = useLayoutTabs.getIndexById(tab.id);
        useLayoutTabs.activeTab(tab.id, <number>index)
      } else {
        // 如果没有 tab 则打开新的 tab
        useLayoutTabs.openTab(<string>name, to.meta.title ?? ' ', to.path)
      }
      break;
    // 这种类型的路由一定是菜单，菜单的 dataId 与路由的 name 相同
    case TargetEnum.FIRST_TAB:

      break;
  }
  // 如果当前路由无需身份验证则直接跳转，需要进行验证
  if (to.meta.offAuth) {
    return true;
  }
  // 检查用户是否已登录，路由守卫里的时间差比定时器的短，为了防止定时器还没有来得及刷新token
  if (useAuthStore().tokenTimeout - Date.now() < 1000 * 60 * 2) {
    // 如果存在 refreshToken 并且没有在获取 token 的情况下去尝试获取 token
    if (useAuthStore().refreshToken) {
      if (!useAuth.isRefreshing) {
        try {
          await useAuth.refreshToken();
          // token 获取成功则放行
          return true
        } catch {
        }
      } else {
        // 如果当前正在获取 token 则等待 token 获取
        const isSuccess = await useAuth.refreshFinish();
        // 完成了获取 并且状态为未超时，则放行
        if (isSuccess && !useAuth.isTimeout()) {
          return true
        }
      }
    }
    // 将用户重定向到登录页面
    console.warn('登录已过期，需要重新登录!!! 路由地址 =>', to.fullPath)
    useAuthStore().loginRedirectUrl = to.fullPath
    return {name: 'loginPage'}
  }
})

router.afterEach(() => {
  nProgress.done()
})

export default router;