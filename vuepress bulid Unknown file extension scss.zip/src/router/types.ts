/**
 * 打开类型
 */
export enum TargetEnum {
  /**
   * 当前页面直接打开
   */
  _SELF,
  /**
   * 打开新的 tab
   */
  NEW_TAB,
  /**
   * 替换第一个标签
   */
  FIRST_TAB,
  /**
   * 打开新的浏览器窗口
   */
  _BLANK,
}