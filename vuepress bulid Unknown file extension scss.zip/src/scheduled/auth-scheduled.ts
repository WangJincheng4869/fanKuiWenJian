class AuthScheduled {

  /**
   * 定时器间隔时间（单位：毫秒）
   */
  private static readonly TIMEOUT = 1000 * 10;

  /**
   * 定时刷新token，每10秒执行一次
   */
  public refreshToken() {
    // 如果超时了则进行token的更新，刷新token的前提是要存在token
    if (useAuth.getAccessToken() && useAuth.getRefreshToken() && useAuth.isTimeout() && !useAuth.isRefreshing) {
      useAuth.refreshToken().catch(reason => {
        console.error(`定期刷新token失败 =>`, reason)
      }).finally(() => {
        setTimeout(authScheduled.refreshToken, AuthScheduled.TIMEOUT)
      })
    } else {
      setTimeout(authScheduled.refreshToken, AuthScheduled.TIMEOUT)
    }
  }

}

export const authScheduled = new AuthScheduled();