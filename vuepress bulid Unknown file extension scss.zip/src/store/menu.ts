import { defineStore } from "pinia";
import { StoreIdConsts } from "@/constant/store-id-consts";
import { RemovableRef, useSessionStorage } from "@vueuse/core";
import { SessionStorageKeyConsts } from "@/constant/session-storage-key-consts";
import { LayoutMenu } from "@/layout/hooks/use-layout-menu/types";
import { i18n } from "@/config/i18n";

const {t} = i18n.global;

/**
 * 首页菜单状态管理<br>
 * 使用 store 的名字，同时以 `use` 开头且以 `Store` 结尾。(比如 `useUserStore`，`useCartStore`，`useProductStore`)
 * 第一个参数是你的应用中 Store 的唯一 ID。
 */
export const useMenuStore = defineStore(StoreIdConsts.MENU, () => {

  const defaultLayoutMenu: LayoutMenu[] = [{
    id: 1,
    parentId: 0,
    menuName: t('menu.home'),
    isBlank: 0,
    isIframe: 0,
    dataId: 'home',
    icon: 'home',
    url: 'home',
    children: []
  }]

  // 全部菜单数据，这是一个嵌套的数据结构，第一层就是一级菜单
  const menus = reactive<RemovableRef<LayoutMenu[]>>(useSessionStorage<LayoutMenu[]>(SessionStorageKeyConsts.MENU, defaultLayoutMenu))

  // 使用Map形式存储菜单数据，方便展示子菜单数据
  const menuMap = computed<Map<string, LayoutMenu>>(() => {
    let map = new Map<string, LayoutMenu>()
    menus.value.forEach(menu => {
      map.set(menu.dataId, menu)
    })
    return map;
  })

  return {menus, menuMap}
})
