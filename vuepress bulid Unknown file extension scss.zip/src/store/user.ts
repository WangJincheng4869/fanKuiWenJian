import { defineStore } from "pinia";
import { StoreIdConsts } from "@/constant/store-id-consts";
import { useSessionStorage } from "@vueuse/core";
import { SessionStorageKeyConsts } from "@/constant/session-storage-key-consts";
import { UserDetails, UserSkill } from "@/layout/hooks/use-user/types";
import { SkillCodeConsts } from "@/constant/skill-code-consts";

/**
 * 用户信息状态管理<br>
 * 使用 store 的名字，同时以 `use` 开头且以 `Store` 结尾。(比如 `useUserStore`，`useCartStore`，`useProductStore`)
 * 第一个参数是你的应用中 Store 的唯一 ID。
 */
export const useUserStore = defineStore(StoreIdConsts.USER, () => {
  // 存储用户信息
  const userDetails = useSessionStorage<UserDetails>(SessionStorageKeyConsts.USER_DETAILS, <UserDetails>{});
  // 存储用户技能信息
  const userSkills = useSessionStorage<UserSkill[]>(SessionStorageKeyConsts.USER_SKILLS, []);
  // 存储全部的技能码
  const skillCodes = computed(() => {
    const codes = new Set<string>();
    userSkills.value.forEach(skill => {
      codes.add(skill.skillCode)
    })
    return codes;
  })
  // 当然用户是否为管理员
  const isAdministrator = computed(() => {
    if (userDetails.value.employeeNumber === 'admin') {
      return true;
    }
    return skillCodes.value.has(SkillCodeConsts.BP_ADMINISTRATOR);
  })
  return {userDetails, userSkills, skillCodes, isAdministrator}
})