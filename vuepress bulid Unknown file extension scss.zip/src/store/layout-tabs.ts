import { defineStore } from "pinia";
import { StoreIdConsts } from "@/constant/store-id-consts";
import { RemovableRef, useSessionStorage } from "@vueuse/core";
import { SessionStorageKeyConsts } from "@/constant/session-storage-key-consts";
import { LayoutActiveTab } from "@/layout/hooks/use-layout-tabs/types";
import { LayoutTabsNavItem } from "@/layout/components/tabs-header/types";
import { ComputedRef, Ref } from "vue";
import { i18n } from "@/config/i18n";
import { RouteRecordName } from "vue-router";

const {t} = i18n.global;

/**
 * 首页 tabs 标签页状态管理，用于存储打开的标签页<br>
 * 使用 store 的名字，同时以 `use` 开头且以 `Store` 结尾。(比如 `useUserStore`，`useCartStore`，`useProductStore`)
 * 第一个参数是你的应用中 Store 的唯一 ID。
 */
export const useLayoutTabsStore = defineStore(StoreIdConsts.LAYOUT_TABS, (): TabsStore => {

  // 默认的标签页数据，初始数据必有首页
  const defaultTabs = useSessionStorage<LayoutTabsNavItem[]>(SessionStorageKeyConsts.LAYOUT_TABS, [{
    id: 'home',
    isIframe: false,
    routerName: 'home',
    name: t('menu.home'),
    closable: false,
    activeMenuBreadcrumb: [1]
  }]);

  // 全部的标签页
  const tabs = reactive(defaultTabs);

  // 当前选中的tab，默认为首页
  const activeTab = reactive(useSessionStorage<LayoutActiveTab>(SessionStorageKeyConsts.LAYOUT_ACTIVE_TAB, {id: 'home', index: 0, activeMenuBreadcrumb: ['home']}))

  // 当前滚动条距左距离
  const nowScrollLeft = ref(0)

  // 全部标签页 Ref
  const tabRefs = reactive<Map<string, Ref<HTMLDivElement>>>(new Map())

  // 使用标签页 id 为 key 存贮标签页的 index
  const tabIndexMap = computed(() => {
    let map = new Map<string, number>();
    tabs.value.forEach((tab, i) => {
      map.set(tab.id, i)
    })
    return map
  })

  // 使用标签页 path 为 key 存贮标签页
  const tabRouterNameMap = computed(() => {
    let map = new Map<RouteRecordName, LayoutTabsNavItem>();
    tabs.value.forEach(tab => {
      if (tab.routerName) map.set(tab.routerName, tab)
    })
    return map
  })

  return {tabs, activeTab, nowScrollLeft, tabRefs, tabIndexMap, tabRouterNameMap}
})

interface TabsStore {
  /**
   * 全部的标签页
   */
  tabs: RemovableRef<LayoutTabsNavItem[]>
  /**
   * 当前选中的tab，默认为首页
   */
  activeTab: RemovableRef<LayoutActiveTab>
  /**
   * 当前滚动条距左距离
   */
  nowScrollLeft: Ref<number>
  /**
   * 全部标签页 Ref
   */
  tabRefs: Map<string, Ref<HTMLDivElement>>
  /**
   *  使用标签页 id 为 key 存贮标签页的 index
   */
  tabIndexMap: ComputedRef<Map<string, number>>
  /**
   *  使用标签页 path 为 key 存贮标签页
   */
  tabRouterNameMap: ComputedRef<Map<RouteRecordName, LayoutTabsNavItem>>
}