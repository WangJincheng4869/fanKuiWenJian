<script setup lang="ts">
import { ElConfigProvider } from 'element-plus';
import zhCN from 'element-plus/lib/locale/lang/zh-cn';
import en from 'element-plus/lib/locale/lang/en';
import { computed } from "vue";
import { useI18n } from "vue-i18n";

const {locale} = useI18n();

const elLocaleData = computed(() => {
  switch (locale.value) {
    case "zh-CN":
      return zhCN
    case "en":
      return en
    default:
      return zhCN
  }
})
</script>

<template>
  <el-config-provider :locale="elLocaleData">
    <!-- 路由匹配到的组件将渲染在这里 -->
    <router-view></router-view>
  </el-config-provider>
</template>

<style scoped>
</style>
