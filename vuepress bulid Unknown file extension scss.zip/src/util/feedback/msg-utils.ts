class MsgUtils {

  /**
   * 成功消息框
   * @param msg 消息内容
   * @param duration 自动关闭时间（毫秒，0为不自动关闭）
   */
  public success(msg: string, duration = 3000){
    ElMessage({
      showClose: true,
      message: msg,
      type: 'success',
      duration: duration
    })
  }

  /**
   * warning消息框
   * @param msg 消息内容
   * @param duration 自动关闭时间（毫秒，0为不自动关闭）
   */
  public warning(msg: string, duration = 3000) {
    ElMessage({
      showClose: true,
      message: msg,
      type: 'warning',
      duration: duration
    })
  }

  /**
   * info消息框
   * @param msg 消息内容
   * @param duration 自动关闭时间（毫秒，0为不自动关闭）
   */
  public info(msg: string, duration = 3000) {
    ElMessage({
      showClose: true,
      message: msg,
      type: 'info',
      duration: duration
    })
  }

  /**
   * error消息框
   * @param msg 消息内容
   * @param duration 自动关闭时间（毫秒，0为不自动关闭）
   */
  public error(msg: string, duration = 3000) {
    ElMessage({
      showClose: true,
      message: msg,
      type: 'error',
      duration: duration
    })
  }

}

export const msgUtils = new MsgUtils();