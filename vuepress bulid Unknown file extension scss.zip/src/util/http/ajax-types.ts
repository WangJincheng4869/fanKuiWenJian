
/**
 * api接口返回统一类型
 */
export interface ResultVO<T> {
  /**
   * 请求状态码
   */
  status: ResultStatusEnum | number;
  /**
   * 返回消息
   */
  msg: string;
  /**
   * 异常消息
   */
  errMsg: string;
  /**
   * 返回的数据
   */
  data: T;
}

/**
 * 请求状态码枚举
 */
export enum ResultStatusEnum {
  /**
   * 请求成功
   */
  SUCCESS = 10000,

  /**
   * 服务不可用
   */
  SERVER_NOT_AVAILABLE = 20000,

  /**
   * 授权权限不足
   */
  INSUFFICIENT_PERMISSION = 20001,

  /**
   * 非法参数：缺少必选参数或必填为null
   */
  ILLEGAL_PARAM_NULL = 40000,

  /**
   * 非法参数：存在非法字符
   */
  ILLEGAL_PARAM_CHAR = 40001,

  /**
   * <p>非法参数：存在无效的参数</p>
   * <p>例如配置表中的配置项，传入非配置项的参数</p>
   */
  ILLEGAL_PARAM_INVALID = 40002,

  /**
   * <p>非法参数：加密参数无效</p>
   * <p>需要加密参数的参数，无法进行解密</p>
   */
  ILLEGAL_PARAM_ENCRYPTION_INVALID = 40003,

  /**
   * <p>禁止操作：数据被占用</p>
   * <p>例如：如果该条数据正在被使用，不能被修改或删除</p>
   */
  PROHIBIT_OPERATE_DATA_OCCUPY = 40004,
  /**
   * <p>禁止操作：状态异常</p>
   */
  PROHIBIT_OPERATE_ABNORMAL_STATE = 40005,
  /**
   * 系统异常
   */
  ERROR_SYSTEM = 50000,
}