class UrlUtils {

  /**
   * 匹配斜线结尾
   */
  private static readonly END_SLASH_RE = /\/+$/;
  /**
   * 匹配斜线开头
   */
  private static readonly START_SLASH_RE = /^\/+/;
  /**
   * 匹配斜线开头和结尾
   */
  private static readonly START_AND_END_SLASH_RE = /(^\/+)|(\/+$)/g;

  /**
   * 删除url地址结尾的/，无论有几个都会被删除
   * @param url
   */
  public removeEndSlash(url: string): string {
    if (url) {
      return url.replace(UrlUtils.END_SLASH_RE, '');
    }
    return ''
  }

  /**
   * 删除url地址开头的/，无论有几个都会被删除
   * @param url
   */
  public removeStartSlash(url: string): string {
    if (url) {
      return url.replace(UrlUtils.START_SLASH_RE, '');
    }
    return ''
  }

  /**
   * 删除url地址开头和结尾的/，无论有几个都会被删除
   * @param url
   */
  public removeStartAndEndSlash(url: string): string {
    if (url) {
      return url.replace(UrlUtils.START_AND_END_SLASH_RE, '');
    }
    return ''
  }

  /**
   * 拼接地址，会自动去除开头和结尾的 / 后再拼接
   * @param path 主 path
   * @param paths 动态参数 path
   */
  public appendUrl(path: string, ...paths: string[]){
    let tempPath = this.removeStartAndEndSlash(path)
    if (paths) {
      paths.forEach(value => {
        tempPath += ('/' + this.removeStartAndEndSlash(value));
      })
    }
    return tempPath
  }
}

export const urlUtils = new UrlUtils();