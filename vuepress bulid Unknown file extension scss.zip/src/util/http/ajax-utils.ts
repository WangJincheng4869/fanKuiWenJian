import axios, { AxiosInstance, AxiosRequestConfig, CreateAxiosDefaults, InternalAxiosRequestConfig } from "axios";
import { i18n } from "@/config/i18n";
import { ResultVO } from "@/util/http/ajax-types";
import { minimatch } from "minimatch";

const {t} = i18n.global;

export class AjaxUtils {

  /**
   * 刷新 token 时的请求队列
   */
  public static requestQueuing = new Array<Function>();

  /**
   * 重复请求异常名
   */
  private static readonly REPEAT_REQUEST_ERROR_NAME = 'spRepeatRequest'
  /**
   * 忽略权限验证的接口 url，这些 url 不进行 token 超时验证，使用 glob 语法规则
   */
  private static readonly IGNORE_AUTH_URL_PATTERNS = ['sso_auth/**']
  /**
   * Axios 实例
   */
  private instance: AxiosInstance = axios.create();

  /**
   * 存储正在请求中的请求，防止重复请求
   */
  private pendingAbortSet: Set<string> = new Set()

  /**
   * 生成检测是否为重复请求key
   * @param config axios 配置参数
   */
  private buildPendingAbortKey(config: InternalAxiosRequestConfig) {
    const {method, url, params, data} = config;
    return (method ?? '') + (url ?? '') + (params ? JSON.stringify(params) : '') + (data ? JSON.stringify(data) : '')
  }

  /**
   * 删除当前请求
   * @param config axios 配置参数
   */
  private deletePendingAbort(config: InternalAxiosRequestConfig) {
    const key = this.buildPendingAbortKey(config);
    this.pendingAbortSet.delete(key)
  }

  /**
   * 将 jwt 添加到 header 中
   * @param config axios 配置参数
   * @param token jwt
   */
  private addAuthorizationHeader(config: InternalAxiosRequestConfig, token: string) {
    config.headers.Authorization = `Bearer ${token}`;
  }

  /**
   * 将当前请求暂停，存放在请求队列中，等待 token 获取完成后执行
   * @param config 当前请求的 axios 配置信息
   */
  private pushRequestQueuing(config: InternalAxiosRequestConfig) {
    return new Promise<InternalAxiosRequestConfig>(resolve => {
      AjaxUtils.requestQueuing.push((token: string) => {
        this.addAuthorizationHeader(config, token)
        resolve(config);
      });
    });
  }

  /**
   * 创建 Ajax 工具类实例
   * @param config axios 配置参数，可以配置 baseURL
   */
  public constructor(config?: CreateAxiosDefaults) {
    this.instance = axios.create(config);
    // 添加请求拦截器
    this.instance.interceptors.request.use(
        config => {
          // 在发送请求之前将token存入header
          this.addAuthorizationHeader(config, useAuth.getAccessToken())
          // 判断当前请求是否已经发出，如果已经发出则抛出异常拦截
          const pendingAbortKey = this.buildPendingAbortKey(config);
          if (this.pendingAbortSet.has(pendingAbortKey)) {
            const error = new Error(`请求重复已拦截:${config.url}`);
            error.name = AjaxUtils.REPEAT_REQUEST_ERROR_NAME
            return Promise.reject(error)
          }
          // 将当前请求存入 map 中
          this.pendingAbortSet.add(pendingAbortKey);
          // 判断当前 url 是否为忽略验证 url
          if (AjaxUtils.IGNORE_AUTH_URL_PATTERNS.some(pattern => minimatch(config.url ?? '', pattern))) {
            return config
          }
          // 如果 token 已超时则刷新 token，无法刷新则跳转至登录页
          if (useAuth.isTimeout()) {
            return new Promise(resolve => {
              // 如果当前没有做刷新 token 操作，则刷新 token
              if (!useAuth.isRefreshing) {
                useAuth.refreshToken().then(data => {
                  AjaxUtils.requestQueuing.forEach(request => request(data.accessToken))
                }).catch(() => {
                  console.warn(`axios请求拦截器刷新token失败`)
                  useAuth.goLogin()
                }).finally(() => {
                  // 需要清空以访问的链接记录，防止无法访问
                  this.pendingAbortSet.clear()
                  // 清空访问队列，无论是请求完成还是需要重新登录
                  AjaxUtils.requestQueuing = []
                })
              } else {
                // 如果当前正在刷新 token 则缓存请求，等待token刷新后再执行
                resolve(this.pushRequestQueuing(config))
              }
            })
          }
          return config;
        },
        function (error) {
          // 对请求错误做些什么
          return Promise.reject(error);
        }
    );
    // 添加响应拦截器
    this.instance.interceptors.response.use(
        (response) => {
          // 请求成功后删除请求 key
          this.deletePendingAbort(response.config)
          // 请求成功直接提取接口返回的内容
          return response.data;
        },
        async (error) => {
          // 处理非重复请求异常
          if (error?.name !== AjaxUtils.REPEAT_REQUEST_ERROR_NAME) {
            try {
              // 如果 error 对象中存在 axios 配置信息则删除当前请求
              if (error?.config) {
                this.deletePendingAbort(error.config)
              } else {
                // 如果没有则清空，防止无法访问
                this.pendingAbortSet.clear()
              }
              if (error.response.status === 401) {
                // 如果存在 refreshToken 则尝试刷新 token
                if (useAuth.getRefreshToken()) {
                  // 如果没在刷新 token 则尝试刷新 token
                  if (!useAuth.isRefreshing) {
                    try {
                      const accessTokenDTO = await useAuth.refreshToken();
                      // 刷新成功则重新请求
                      this.addAuthorizationHeader(error.config, accessTokenDTO.accessToken)
                      console.log('token 重新获取成功，恢复接口访问 =>', error.config.url)
                      return ajax.request(error.config)
                    } catch {
                    }
                  } else {
                    // 如果当前正在刷新 token 则等待刷新完成再做判断
                    let isFinish = await useAuth.refreshFinish()
                    if (isFinish && !useAuth.isTimeout()) {
                      // 刷新成功则重新请求
                      this.addAuthorizationHeader(error.config, useAuth.getAccessToken())
                      console.log('token 重新获取成功，恢复接口访问 =>', error.config.url)
                      return ajax.request(error.config)
                    }
                  }
                }
                useAuth.goLogin()
              } else if (error.response.status === 403) {
                msgUtils.warning(t("msg.warning.httpForbiddenContactAdministrator"));
                console.warn(`接口权限不足，请求url=${error.config.url}`);
              }
            } catch (e) {
              console.error(e, "axios异常拦截器处理异常，可以忽略此错误");
            }
          }
          return Promise.reject(error);
        }
    );
  }

  /**
   * get请求
   * @param url 接口地址
   * @param params 参数对象
   * @param timeout 超时时间（毫秒）
   */
  public get<T>(url: string, params?: any, timeout: number = 0): Promise<ResultVO<T>> {
    return this.instance.get(url, {
      params,
      timeout,
    });
  }

  /**
   * 表单形式使用post请求提交数据到服务端
   * @param url 接口地址
   * @param params 参数对象
   * @param config 配置信息
   */
  public post<T>(url: string, params?: any, config?: AxiosRequestConfig): Promise<ResultVO<T>> {
    const formData = new FormData();
    for (const paramsKey in params) {
      formData.append(paramsKey, params[paramsKey]);
    }
    return this.instance.post(url, formData, config);
  }

  /**
   * 表单形式使用post请求提交数据到服务端，可提交文件并可监听文件上传进度
   * @param url 接口地址
   * @param params 参数对象
   * @param onUploadProgress 文件上传进度事件
   */
  public postFile<T>(url: string, params?: any, onUploadProgress?: (progressEvent: any) => void): Promise<ResultVO<T>> {
    const formData = new FormData();
    for (const paramsKey in params) {
      formData.append(paramsKey, params[paramsKey]);
    }
    return this.instance.post(url, formData, {
      onUploadProgress: function (evt) {
        if (onUploadProgress) onUploadProgress(evt);
      },
    });
  }

  /**
   * 使用raw模式将参数写在body中以JSON形式发给服务端
   * @param url 接口地址
   * @param params 接口参数对象
   */
  public postRawJson<T>(url: string, params?: any): Promise<ResultVO<T>> {
    return this.instance.post(url, params, {
      transformRequest: [
        //转化要传入的为字符串
        function (data) {
          return JSON.stringify(data);
        },
      ],
      headers: {
        "Content-Type": "application/json",
      },
    });
  }

  /**
   * 表单形式使用put请求提交数据到服务端
   * @param url 接口地址
   * @param params 参数对象
   * @param config 配置信息
   */
  public put<T>(url: string, params?: any, config?: AxiosRequestConfig): Promise<ResultVO<T>> {
    const formData = new FormData();
    for (const paramsKey in params) {
      formData.append(paramsKey, params[paramsKey]);
    }
    return this.instance.put(url, formData, config);
  }

  /**
   * 使用raw模式将参数写在body中以JSON形式发给服务端
   * @param url 接口地址
   * @param params 接口参数对象
   */
  public putRawJson<T>(url: string, params?: any): Promise<ResultVO<T>> {
    return this.instance.put(url, params, {
      transformRequest: [
        //转化要传入的为字符串
        function (data) {
          return JSON.stringify(data);
        },
      ],
      headers: {
        "Content-Type": "application/json",
      },
    });
  }

  /**
   * 表单形式删除数据
   * @param url 接口地址
   * @param params 接口参数对象
   * @param timeout 超时时间（毫秒）
   */
  public del<T>(url: string, params?: any, timeout: number = 0): Promise<ResultVO<T>> {
    return this.instance.delete(url, {params, timeout});
  }

  /**
   * 完整的请求，你可以进行自定配置
   * @param config 请求配置项，详见 {@link https://www.axios-http.cn/docs/req_config"}
   */
  public request<T>(config: AxiosRequestConfig): Promise<ResultVO<T>> {
    return this.instance.request(config);
  }
}

/**
 * Ajax工具类，这是没有baseURL的工具类
 */
const ajax = new AjaxUtils();

/**
 * 单点登录模块 Ajax 工具类，加入了 baseURL，请求地址为 baseURL + url（你不必纠结 baseURL 结尾是否需要有 /，或者 url 之前是否有 /。因为 axios 会去处理）
 */
const ajaxSso = new AjaxUtils({
  baseURL: apiBaseUrl.sso,
});

/**
 * 配置模块 Ajax 工具类，加入了 baseURL，请求地址为 baseURL + url（你不必纠结 baseURL 结尾是否需要有 /，或者 url 之前是否有 /。因为 axios 会去处理）
 */
const ajaxConfig = new AjaxUtils({
  baseURL: apiBaseUrl.config,
});

export { ajax, ajaxSso, ajaxConfig };
