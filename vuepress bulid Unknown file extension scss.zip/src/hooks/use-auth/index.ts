import { useAuthStore } from "@/store/auth";
import { TokenDTO } from "@/hooks/use-auth/types";
import { ajaxSso } from "@/util/http/ajax-utils";
import router from "@/router";
import { i18n } from "@/config/i18n";

const {t} = i18n.global;
class UseAuth {
  /**
   * 当前是否在刷新 token，防止重复刷新token
   */
  public isRefreshing = false;

  private loginAlerted = false;

  /**
   * token超时时间冗余值，差五分钟超时就算超时，需要重新获取token
   */
  private static readonly TOKEN_TIMEOUT_THRESHOLD = 1000 * 60 * 5;


  /**
   * 获取当前token是否超时
   */
  public isTimeout(): boolean {
    let tokenTimeout = useAuthStore().tokenTimeout;
    return tokenTimeout - Date.now() < UseAuth.TOKEN_TIMEOUT_THRESHOLD
  }


  /**
   * 获取 accessToken（非响应式数据）
   */
  public getAccessToken(): string {
    return useAuthStore().accessToken
  }

  /**
   * 获取 refreshToken（非响应式数据）
   */
  public getRefreshToken(): string {
    return useAuthStore().refreshToken
  }

  /**
   * 更新accessToken
   * @param accessTokenDTO 接口返回的accessToken对象
   */
  public updateToken(accessTokenDTO: TokenDTO): void {
    useAuthStore().accessToken = accessTokenDTO.accessToken
    useAuthStore().refreshToken = accessTokenDTO.refreshToken
    useAuthStore().tokenTimeout = accessTokenDTO.expiresIn * 1000 + Date.now()
  }

  /**
   * 让 token 无效
   */
  public invalidate(){
    useAuthStore().accessToken = ''
    useAuthStore().refreshToken = ''
    useAuthStore().tokenTimeout = 0
  }

  /**
   * 刷新 token
   */
  public refreshToken() {
    this.isRefreshing = true
    return new Promise<TokenDTO>((resolve, reject) => {
      ajaxSso.post<TokenDTO>(`sso_auth/refresh_access_token`, {
        refreshToken: this.getRefreshToken()
      }, {
        timeout: 2000
      }).then(result => {
        if (result.status === ResultStatusEnum.SUCCESS) {
          this.updateToken(result.data);
          resolve(result.data)
        } else {
          this.invalidate()
          console.warn('刷新token失败 => ', result)
          reject()
        }
      }).catch((error) => {
        this.invalidate()
        console.warn('刷新token异常 => ', error)
        reject(error)
      }).finally(() => {
        this.isRefreshing = false
      })
    })
  }

  /**
   * 跳转至登录页面
   */
  public goLogin() {
    // 如果已经弹出，则不在弹出
    if (this.loginAlerted) {
      return
    }
    this.loginAlerted = true
    msgBoxUtils.alert(t('msg.warning.loginTimeoutReLogin'), t("title.warning"),{
      showClose: false,
      type: 'warning'
    }).then(() => {
      router.replace({name: "loginPage"});
    }).finally(() => {
      this.loginAlerted = false
    })
  }

  /**
   * 用于判断获取 token 是否完成
   */
  public refreshFinish(){
    return new Promise<boolean>((resolve, reject) => {
      let timeout = 0
      setInterval(() => {
        // 最多等待两秒，则超时失败
        if (timeout > 100) {
          reject(false)
        }
        if (!this.isRefreshing) {
          resolve(true)
        }
        timeout++
      }, 20)
    })
  }

  /**
   * 重置登录重定向路径
   */
  public resetLoginRedirectUrl() {
    useAuthStore().loginRedirectUrl = '/'
  }
}

export const useAuth = new UseAuth();