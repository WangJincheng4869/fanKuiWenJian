import { useSettingStore } from "@/store/setting";
import { storeToRefs } from "pinia";
import { Ref } from "vue";
import { BpSetting } from "@/hooks/use-setting/types";

/**
 * 用户设置工具类
 */
class UseSetting {

  /**
   * 获取用户设置（非响应式对象）
   */
  getSetting() {
    return useSettingStore().setting
  }

  /**
   * 获取用户设置（响应式对象）
   */
  getSettingRefs(): Ref<BpSetting> {
    return this.getSettingStoreRefs().setting
  }

  /**
   * 获取响应式的 store
   */
  private getSettingStoreRefs(){
    return storeToRefs(useSettingStore())
  }

}

export const useSetting = new UseSetting();