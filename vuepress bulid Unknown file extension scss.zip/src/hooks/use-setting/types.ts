export interface BpSetting {
  /**
   * 新标签页打开方式 0-当前活动会话后 1-最后以后标签后
   */
  newTabOpenType?: number;

  /**
   * 可扩展其他属性
   */
  [propName: string]: number | string | undefined;
}