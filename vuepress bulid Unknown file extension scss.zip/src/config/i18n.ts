// element-plus国际化
import enLocale from "element-plus/lib/locale/lang/en";
import zhLocale from "element-plus/lib/locale/lang/zh-cn";
import { createI18n, Locale, useI18n } from "vue-i18n";
import { useStorage } from "@vueuse/core";
// 切换语言使用的类型
export type SwitchI18nLang = 'zh-CN' | 'en' | Locale;

// 存储语言类型的key
const storageKey = 'locale';

// 支持的语言字符串类型
const localeName = {
  zhCN: 'zh-CN',
  en: 'en'
}

/**
 * 抽取多语言数据
 * @param prefix 多语言文件前缀，即语言类型
 */
function siphonI18n(prefix: SwitchI18nLang = localeName.zhCN) {
  const i18n: any = {};
  // 将所有多语言翻译内容读取出来，读取出来数据结构是一个对象。例：{'../../locale/zh-CN.yml': {}, '../../locale/en.yml': {}}
  let localeRecord: Record<string, any> = import.meta.glob("../../locales/*.yml", {eager: true});
  Object.keys(localeRecord).forEach(key => {
    // 将文件后缀去掉，作为多语言翻译存储的key
    const matched = key.match(/([A-Za-z0-9-_]+)\./i);
    if (matched) {
      // 如果提取成功，则数组内第二项为去除掉.yml的值
      let localeKey = matched[1]
      i18n[localeKey] = localeRecord[key].default;
    }
  });
  return i18n[prefix];
}

/**
 * 获取当前语言类型
 */
function getStorageLocale(): SwitchI18nLang {
  const locale = useStorage(storageKey, localeName.zhCN);
  switch (locale.value) {
    case localeName.en:
      return localeName.en
    default:
      return localeName.zhCN
  }
}

/**
 * 全部多语言数据
 */
export const localesConfigs = {
  'zh-CN': {
    ...siphonI18n(localeName.zhCN),
    ...zhLocale
  },
  en: {
    ...siphonI18n(localeName.en),
    ...enLocale
  }
};


/**
 * 初始化i18n组件
 */
export const i18n = createI18n<false>({
  legacy: false,
  locale: getStorageLocale(),
  fallbackLocale: localeName.zhCN,
  messages: localesConfigs
});

/**
 * i18n工具类
 */
export function i18nUtils() {
  // useI18n必须写在setup中，故要写在这里，在setup中解构此方法，拿到switchI18n进行使用
  const {locale, t} = useI18n();
  // 全部支持的语言类型
  const locales = {
    'zh-CN': t('locale.simplifiedChinese'),
    'en': t('locale.english')
  }
  const localeStorage = useStorage(storageKey, localeName.zhCN);
  /**
   * 语言切换
   * @param lang 支持字符串 zh-CN、en
   */
  const switchI18n = (lang: SwitchI18nLang = localeName.zhCN) => {
    if (Object.keys(locales).indexOf(lang) > -1) {
      locale.value = lang
      localeStorage.value = lang;
      document.querySelector('html')?.setAttribute('lang', lang)
    } else {
      console.warn(`切换的语言不支持，默认切换为中文 lang=${lang}`)
      locale.value = localeName.zhCN
      localeStorage.value = localeName.zhCN;
      document.querySelector('html')?.setAttribute('lang', localeName.zhCN)
    }
  }

  return {switchI18n, locales}
}