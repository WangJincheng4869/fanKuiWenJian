/**
 * 存储系统全部 SessionStorage 的存储 Key
 */
export class SessionStorageKeyConsts {

  /**
   * accessToken 存储 key
   */
  static readonly ACCESS_TOKEN = 'bp_accessToken'

  /**
   * refreshToken 存储 key
   */
  static readonly REFRESH_TOKEN = 'bp_refreshToken'

  /**
   * accessToken 超时时间戳 存储 key
   */
  static readonly ACCESS_TOKEN_TIMEOUT = 'bp_accessTokenTimeout'

  /**
   * 当前用户信息
   */
  static readonly USER_DETAILS = 'bp_userDetails'

  /**
   * 当前用户的全部技能
   */
  static readonly USER_SKILLS = 'bp_userSkills'

  /**
   * 用于记录用户访问被拦截到登录页面的url，用于登陆后的跳转
   */
  static readonly LOGIN_REDIRECT_URL = "bp_loginRedirectUrl";

  /**
   * 首页 tabs 标签页存储 Key
   */
  static readonly LAYOUT_TABS = 'bp_LayoutTabs'
  /**
   * 首页 tabs 标签页默认选中存储 Key
   */
  static readonly LAYOUT_ACTIVE_TAB = 'bp_LayoutActiveTab'
  /**
   * 用户设置状态管理，用于存储当前用户配置（包含系统配置）
   */
  static readonly SETTING = 'bp_setting'
  /**
   * 用户菜单数据存储
   */
  static readonly MENU = 'bp_menu'
}