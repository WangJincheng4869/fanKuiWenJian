export class SkillCodeConsts {
  /**
   * 系统管理员<br>
   * 技能类型：系统技能<br>
   * 拥有此技能的座席会拥有部分管理员权限，如：高级系统设置，可以设置系统的通用功能
   **/
  static readonly BP_ADMINISTRATOR: string = "bp_administrator";
}