/**
 * 存储系统全部 LocalStorage 的存储 Key
 */
export class LocalStorageKeyConsts {

}