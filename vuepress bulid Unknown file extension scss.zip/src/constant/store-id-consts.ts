/**
 * 状态管理唯一 Id 常量类
 */
export class StoreIdConsts {

  /**
   * 权限状态管理，用于全局存在用户token等信息
   */
  static readonly AUTH = 'auth'
  /**
   * 首页 tabs 标签页状态管理，用于存储打开的标签页
   */
  static readonly LAYOUT_TABS = 'layoutTabs'
  /**
   * 用户设置状态管理，用于存储当前用户配置（包含系统配置）
   */
  static readonly SETTING = 'setting'
  /**
   * 存储当时用户菜单的数据
   */
  static readonly MENU = 'menu'
  /**
   * 存储当时用户信息，包括技能
   */
  static readonly USER = 'user'
}