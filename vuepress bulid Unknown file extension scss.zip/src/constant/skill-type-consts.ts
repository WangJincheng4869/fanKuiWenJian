/**
 * 技能类型常量
 */
export class SkillTypeConsts {

  /**
   * 系统技能
   **/
  static readonly SYS_SKILL: number = 0;

  /**
   * 呼叫技能
   **/
  static readonly CALL_SKILL: number = 1;

  /**
   * 业务技能
   **/
  static readonly BUSINESS_SKILL: number = 2;

  /**
   * 工作流技能
   **/
  static readonly WORKFLOW_SKILL: number = 3;

  /**
   * 多媒体技能
   **/
  static readonly MULTI_MEDIA_SKILL: number = 4;

  /**
   * 工单技能
   **/
  static readonly WORK_ORDER_SKILL: number = 5;

  /**
   * 统计技能
   **/
  static readonly STATISTICS_SKILL: number = 6;

  /**
   * 客户技能
   **/
  static readonly CUSTOMER_SKILL: number = 7;

  /**
   * 考试技能
   **/
  static readonly EXAM_SKILL: number = 8;

  /**
   * 质检技能
   **/
  static readonly QUALITY_INSPECTION_SKILL: number = 9;
}