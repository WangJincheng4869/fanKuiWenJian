<script setup lang="ts">
import router from "@/router";


</script>

<template>
403
  <el-button type="primary" @click="router.back()">返回</el-button>
</template>

<style lang="scss" scoped>

</style>