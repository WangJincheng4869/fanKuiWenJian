<script setup lang="ts">
import SpIcon from "@/components/icon/SpIcon.vue";
import { useLayoutMenu } from "@/layout/hooks/use-layout-menu";
import { useLayoutTabs } from "@/layout/hooks/use-layout-tabs";

const activeTabRefs = useLayoutTabs.getActiveTabRefs();
const menu = useLayoutMenu.getMenu(activeTabRefs.value.activeMenuBreadcrumb[0])
</script>

<template>
  <div class="sub-menu-box w-full h-full">
    <div class="sub-menu-search-box w-full">
      <div class="menu-search__wrapper w-full">
        <input class="sub-menu-search-input" placeholder="检索菜单"/>
        <div class="menu-search__prefix-inner">
          <sp-icon name="search"/>
        </div>
      </div>
    </div>
    <div class="sub-menu w-full">
      <el-scrollbar>
        <div class="w-full">
          <div class="sub-menu-item">
            <div class="sub-menu-item-group-name">客户管理</div>
            <div class="sub-menu-item-group-item">公司维护</div>
            <div class="sub-menu-item-group-item">客户分组维护</div>
          </div>
          <div class="sub-menu-item">
            <div class="sub-menu-item-group-name">客户管理</div>
            <div class="sub-menu-item-group-item">公司维护</div>
            <div class="sub-menu-item-group-item">客户分组维护</div>
          </div>
        </div>
      </el-scrollbar>
    </div>
  </div>
</template>

<style lang="scss" scoped>

.dark {
  .sub-menu-box {
    --sp-menu-bg-color: #2d3043;
    --sp-menu-search-bg-color: #232532;
    --sp-menu-item-group-color: var(--sp-color-second);
    --sp-menu-item-active-color: #232532;
    --sp-menu-item-hover-color: #292b3a;
    --sp-menu-divider-color: #3e425b;
  }
}

.sub-menu-box {
  --sp-menu-bg-color: var(--sp-bg-color-page);
  --sp-menu-search-bg-color: #e2e3e5;
  --sp-menu-item-group-color: #10100e;
  --sp-menu-item-active-color: #e2e3e5;
  --sp-menu-item-hover-color: #e8e9ea;
  --sp-menu-divider-color: #e6e6e6;

  background-color: var(--sp-menu-bg-color);
  display: flex;
  flex-direction: column;
  overflow: hidden;

  .sub-menu-search-box {
    padding: 14px;
    flex: 0;

    .menu-search__wrapper {
      position: relative;

      .sub-menu-search-input {
        width: 100%;
        height: 34px;
        border-radius: 17px;
        background-color: var(--sp-menu-search-bg-color);
        border: 1px solid transparent;
        outline: none;
        color: var(--el-text-color-regular);
        padding: 0 10px 0 34px;
        transition: border-color var(--el-transition-duration-fast) var(--el-transition-function-ease-in-out-bezier);
      }

      .sub-menu-search-input:focus {
        border: 1px solid #499caa;
      }

      .sub-menu-search-input::placeholder {
        font-size: 15px;
        color: #b3b4b8;
      }

      .menu-search__prefix-inner {
        position: absolute;
        width: 34px;
        height: 34px;
        color: #b3b4b8;
        font-size: 18px;
        top: 0;
        display: flex;
        justify-content: center;
        align-items: center;
        transition: color var(--el-transition-duration-fast) var(--el-transition-function-ease-in-out-bezier);
      }

      .sub-menu-search-input:focus + .menu-search__prefix-inner {
        color: #499caa;
      }
    }
  }

  .sub-menu {

    flex: 1 0 auto;

    .sub-menu-item {
      position: relative;
      padding: 18px 0;

      .sub-menu-item-group-name {
        font-size: 16px;
        padding: 7px 20px;
        color: var(--sp-menu-item-group-color);
      }

      .sub-menu-item-group-item {
        font-size: 14px;
        color: #8b8c8e;
        padding: 7px 20px;
        cursor: pointer;
        transition: background-color var(--el-transition-duration), color var(--el-transition-duration);
      }

      .sub-menu-item-group-item:hover {
        background-color: var(--sp-menu-item-hover-color);
      }

      .sub-menu-item-group-item.active {
        background-color: var(--sp-menu-item-active-color);
      }
    }

    .sub-menu-item:first-child {
      padding-top: 0;
    }

    .sub-menu-item:not(:last-child):after {
      content: ' ';
      position: absolute;
      height: 1px;
      background-color: var(--sp-menu-divider-color);
      width: calc(100% - 30px);
      left: 15px;
      bottom: 0;
    }
  }
}
</style>