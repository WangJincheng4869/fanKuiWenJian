<script setup lang="ts">

import { useMenuStore } from "@/store/menu";
import { useLayoutTabs } from "@/layout/hooks/use-layout-tabs";
import { LayoutMenu } from "@/layout/hooks/use-layout-menu/types";
import SpIcon from "@/components/icon/SpIcon.vue";
import { useI18n } from "vue-i18n";

const menus: LayoutMenu[] = useMenuStore().menus;
const activeTab = useLayoutTabs.getActiveTabRefs();

const isActive = (menu: LayoutMenu) => {
  return activeTab.value.activeMenuBreadcrumb && activeTab.value.activeMenuBreadcrumb[0] === menu.dataId
}

const {t} = useI18n()
</script>

<template>
  <div class="aside-menu w-full h-full">
    <div class="aside-menu-list">
      <el-scrollbar>
        <div class="w-full overflow-hidden">
          <template v-for="menu in menus" :key="menu.id">
            <div :class="['aside-menu-item', {'active': isActive(menu)}]">
              <div class="aside-menu-icon">
                <sp-icon :name="menu.icon ?? 'unknown-animate'"/>
              </div>
              <div class="aside-menu-name">{{ t(`menu.${menu.dataId}`) }}</div>
            </div>
          </template>
        </div>
      </el-scrollbar>
    </div>
    <div class="aside-menu-normal">
      <div class="aside-menu-item">
        <div class="aside-menu-icon">
          <sp-icon name="normal"/>
        </div>
        <div class="aside-menu-name">{{ t(`menu.normal`) }}</div>
      </div>
    </div>
  </div>
</template>

<style lang="scss" scoped>
.dark {
  .aside-menu {
    --sp-bg-color-aside: #35363a;
    --sp-color-aside: #8c8f98;
  }
}

.aside-menu {
  --sp-bg-color-aside: #5b75a8;
  --sp-color-aside: #d2e4e6;

  background-color: var(--sp-bg-color-aside);

  .aside-menu-item {
    user-select: none;
    color: var(--sp-color-aside);
    height: var(--sp-aside-width);
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
    cursor: pointer;
    position: relative;
    font-size: 16px;
    transition: color var(--el-transition-duration) var(--el-transition-function-ease-in-out-bezier);

    .aside-menu-icon {
      height: 18px;
      transition: transform .2s;
    }

    .aside-menu-name {
      font-size: 12px;
      padding-top: 5px;
    }
  }

  .aside-menu-item:not(.active):active {
    transform: scale(.9);
  }

  .aside-menu-item:not(.active):hover {
    .aside-menu-icon {
      transform: scale(1.2);
    }
  }

  .aside-menu-item:hover {
    color: #7effeb;
  }

  .aside-menu-list {
    height: calc(100% - var(--sp-aside-width));

    .aside-menu-item {
      margin-top: 15px;
    }

    .aside-menu-item.active {
      color: #7effeb;

      .active-icon {
        display: block;
      }
    }

    .aside-menu-item.active:after {
      content: ' ';
      width: 5px;
      height: 10px;
      background-color: #7effeb;
      border-top-left-radius: 5px;
      border-bottom-left-radius: 5px;
      position: absolute;
      right: 1px;
    }
  }

  .aside-menu-normal {
    height: var(--sp-aside-width);
  }
}
</style>