import { LocationQueryRaw, RouteParamsRaw, RouteRecordName } from "vue-router";
import router from "@/router";

/**
 * 首页导航 tab 标签页数据类型
 */
export interface LayoutTabsNavItem {
  /**
   * 标签页唯一id，如果重复会导致标签页无法正常使用，当这个tab是菜单
   */
  id: string;
  /**
   * 是否为 iframe 连接
   */
  isIframe: boolean;

  /**
   * 标签是否可关闭
   */
  closable: boolean;

  /**
   * 标签页名称
   */
  name: string;

  /**
   * iframe那么就是访问url
   */
  iframeSrc?: string;

  /**
   * 路由名称
   */
  routerName?: RouteRecordName;

  /**
   * 路由路径参数
   */
  params?: RouteParamsRaw;

  /**
   * 路由参数 ?传参的参数
   */
  query?: LocationQueryRaw;

  /**
   * 激活的菜单id。index-0 需要选中的一级菜单，index-1 需要选中的二级菜单(一般二级菜单没有url则显示为分组) index-2 需要选中的二级菜单(当存在分组的时候，这才是真正的二级菜单)
   */
  activeMenuBreadcrumb: number[];
}