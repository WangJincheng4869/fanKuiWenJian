<script setup lang="ts">
import { ElScrollbar } from "element-plus";
import { useElementSize, useEventListener } from "@vueuse/core";
import { Ref } from "vue";
import { useLayoutTabs } from "@/layout/hooks/use-layout-tabs";
import router from "@/router";
import { LayoutTabsNavItem } from "@/layout/components/tabs-header/types";
import { LayoutActiveTab } from "@/layout/hooks/use-layout-tabs/types";
import TabsItem from "@/layout/components/tabs-header/TabsItem.vue";

const tabs: Ref<LayoutTabsNavItem[]> = useLayoutTabs.getTabsRefs();
const activeTab: Ref<LayoutActiveTab> = useLayoutTabs.getActiveTabRefs();

// 绑定滚轮事件使用
const tabsHeader = ref()
// 用于控制滚动条使用
const scrollbarRef = ref<InstanceType<typeof ElScrollbar>>()
// 用于获取需要滚动的距离使用
const innerRef = ref()
const nowScrollLeft = useLayoutTabs.getNowScrollLeftRefs();

// 容器宽度
const {width: tabsHeaderWidth} = useElementSize(tabsHeader)
// 内容宽度
const {width: innerWidth} = useElementSize(innerRef)

// 最大滚动距离
const maxScrollLeft = computed(() => {
  let max = innerWidth.value + 20 - tabsHeaderWidth.value
  return max > 0 ? max : 0;
})

const scroll = ({scrollLeft}: { scrollLeft: number }) => {
  nowScrollLeft.value = scrollLeft;
}

// 当数据发生改变也要同时更新滚动条，防止滚动条样式出现bug
watch(tabs, () => {
  setTimeout(() => {
    scrollbarRef.value?.update();
  }, 300)
})

/**
 * 设置平滑滚动距离
 * @param index 调用次数
 * @param evt 滚轮事件
 */
const setScrollLeft = (evt: WheelEvent, index = 0) => {
  let offsetLeft = evt.deltaY / 25, // 偏移量
    left = nowScrollLeft.value + offsetLeft; // 便宜后的距左距离
  nowScrollLeft.value = left > 0 ? (left > maxScrollLeft.value ? maxScrollLeft.value : left) : 0;
  scrollbarRef.value!.setScrollLeft(nowScrollLeft.value);
  index++
  if (index < 20) setTimeout(() => setScrollLeft(evt, index), 10)
}

// 监听滚轮事件，完成滚轮直接控制横向滚动条
useEventListener(tabsHeader, 'wheel', (evt: WheelEvent) => {
  // 如果按下了 shift 则代表可以直接触发横向滚动
  if (evt.shiftKey) return;
  setScrollLeft(evt)
})


/**
 * 点击标签页
 * @param tab tab对象
 * @param index 当前tab的 index
 */
const clickTab = (tab: LayoutTabsNavItem, index: number) => {
  activeTab.value.id = tab.id;
  activeTab.value.index = index;
  router.push({name: tab.routerName})
}

onMounted(() => {
  // 挂载后讲 TabsHeaderRef 存储，供判断选中标签页是否在视野内使用
  useLayoutTabs.setTabsScrollbarRef(scrollbarRef)
})
</script>

<template>
  <div class="tabs-header" id="bp_layoutTabsHeader" ref="tabsHeader">
    <el-scrollbar ref="scrollbarRef" @scroll="scroll">
      <div class="tabs-nav" ref="innerRef">
        <template v-for="(item, index) in tabs" :key="item.id">
          <tabs-item :id="item.id" :name="item.name" :closable="item.closable" :active="item.id === activeTab.id" @click="clickTab(item, index)"/>
        </template>
      </div>
    </el-scrollbar>
  </div>
</template>

<style lang="scss" scoped>

.tabs-header {
  width: 100%;
  height: 40px;
  overflow-y: hidden;

  :deep(.el-scrollbar__bar.is-horizontal) {
    height: 2px;
    bottom: 0;
  }

  .tabs-nav {
    height: 100%;
    display: flex;
    padding: 0 10px;
    width: max-content;
  }
}
</style>