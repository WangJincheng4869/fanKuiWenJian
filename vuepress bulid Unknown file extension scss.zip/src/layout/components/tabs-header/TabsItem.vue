<script setup lang="ts">
import { useLayoutTabs } from "@/layout/hooks/use-layout-tabs";
import SpIcon from "@/components/icon/SpIcon.vue";

export interface Props {
  /**
   * 是否可以关闭
   */
  closable: boolean
  /**
   * 是否为选中状态
   */
  active: boolean
  /**
   * 标签名称
   */
  name: string
  /**
   * 标签唯一 id
   */
  id: string
}

const props = withDefaults(defineProps<Props>(), {
  closable: true,
  active: false
})

const tabsItemRef = ref()

onBeforeMount(() => {
  useLayoutTabs.addTabRef(props.id, tabsItemRef)
})
</script>

<template>
  <div :class="['tabs-item', {closable: props.closable, active: props.active}]" ref="tabsItemRef">
    <span class="tabs-name">{{ props.name }}</span>
    <sp-icon v-if="props.closable" class="close-tabs" @click.stop="useLayoutTabs.closeTab(props.id)" name="close"/>
  </div>
</template>

<style lang="scss" scoped>
.tabs-item {
  position: relative;
  max-width: 150px;
  height: 40px;
  display: flex;
  align-items: center;
  flex: 1;
  font-size: var(--el-font-size-base);
  padding: 0 25px;
  color: var(--el-text-color-secondary);
  cursor: pointer;
  text-decoration: none;
  transition: color var(--el-transition-duration) var(--el-transition-function-ease-in-out-bezier), padding var(--el-transition-duration) var(--el-transition-function-ease-in-out-bezier);

  .tabs-name {
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
  }

  .close-tabs {
    width: 0;
    height: 14px;
    font-size: 10px;
    margin-left: 6px;
    transform-origin: 100% 50%;
    border-radius: 50%;
    text-align: center;
    transition: all var(--el-transition-duration) var(--el-transition-function-ease-in-out-bezier);
  }

  .close-tabs:hover {
    background-color: var(--el-text-color-placeholder);
    color: var(--el-color-white);
  }
}

.tabs-item:hover,
.tabs-item.active {
  color: var(--sp-color-second);

  .close-tabs {
    width: 14px;
  }
}

.tabs-item:before {
  position: absolute;
  content: ' ';
  width: 0;
  height: 2px;
  border-radius: 1px;
  background-color: var(--sp-color-second);
  bottom: 0;
  left: 20px;
  transition: width var(--el-transition-duration) var(--el-transition-function-ease-in-out-bezier);
}

.tabs-item.active:before {
  width: calc(100% - 40px);
}


.tabs-item.closable:not(.active):hover {
  padding: 0 18px;
}
</style>