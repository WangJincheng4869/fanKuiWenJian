<script setup lang="ts">

</script>

<template>
主页
  <div style="width: 10000px;height: 10000px"></div>
</template>

<style lang="scss" scoped>

</style>