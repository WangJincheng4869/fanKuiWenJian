<script setup lang="ts">

import TabsHeader from "@/layout/components/tabs-header/TabsHeader.vue";
import AsideMenu from "@/layout/components/aside-menu/AsideMenu.vue";
import { useLayoutTabs } from "@/layout/hooks/use-layout-tabs";
import SubMenu from "@/layout/components/aside-menu/SubMenu.vue";

const add = () => {
  for (let j = 0; j < 30; j++) {
    useLayoutTabs.openTab('ticket1' + j, 'ticket1' + j, '/ticket1')
    ajaxConfig.get<string>('config/test/get_abc', {
      a: j
    }).then(result => {
      if (result.status === ResultStatusEnum.SUCCESS) {
        console.log(result)
      } else if (result.status === ResultStatusEnum.ERROR_SYSTEM) {
        console.warn(result)
      } else {
        console.error(result)
      }
    })
  }
}
</script>

<template>
  <el-container>
    <el-aside class="aside" width="var(--sp-aside-width)">
      <aside-menu/>
    </el-aside>
    <el-container>
      <el-header class="header" height="96px">
        <div class="header-logo">
          <el-button @click="add"></el-button>
          <el-button @click="useLayoutTabs.openTab('ticket', 'ticket', '/ticket')">ticket</el-button>
          <el-button @click="useLayoutTabs.openTab('ticket1', 'ticket1', '/ticket1')">ticket1</el-button>
        </div>
        <div class="header-body">
          <div class="navbar">
          </div>
          <div class="tabs">
            <tabs-header/>
          </div>
        </div>
      </el-header>
      <el-main class="main">
        <div class="sub-menu-container">
          <sub-menu/>
        </div>
        <div class="view-container">
          <div class="router-view">
            <router-view v-slot="{ Component, route }">
              <template v-if="!route.meta.offKeepAlive">
                <keep-alive>
                  <component :is="Component" :key="route.name"/>
                </keep-alive>
              </template>
              <component v-else :is="Component" :key="route.name"/>
            </router-view>
          </div>
          <div class="iframe-view hidden">iframe-view</div>
        </div>
      </el-main>
    </el-container>
  </el-container>
</template>

<style lang="scss" scoped>
.aside {
  height: 100vh;
}

$header-logo-width: 194px;

.dark {
  .header {
    --sp-bg-color-logo: #232532;
  }
}

.header {
  --sp-bg-color-header: var(--sp-bg-color-page);;
  --sp-bg-color-logo: #499caa;

  background-color: var(--sp-bg-color-header);
  padding: 0;
  display: flex;
  overflow: hidden;

  .header-logo {
    width: $header-logo-width;
    height: 100%;
    background-color: var(--sp-bg-color-logo);
    flex-shrink: 0;
  }

  .header-body {
    flex: 1 1 auto;
    overflow: hidden;

    .navbar {
      height: 56px;
      width: 100%;
    }

    .tabs {
      height: 40px;
      width: 100%;
    }
  }
}

.main {
  padding: 0;
  display: flex;
  overflow: hidden;

  .sub-menu-container {
    width: $header-logo-width;
    flex-shrink: 0;
  }

  .view-container {
    position: relative;
    flex: 1 1 auto;

    .router-view,
    .iframe-view {
      width: 100%;
      height: 100%;
      position: absolute;
      top: 0;
    }
  }
}
</style>
