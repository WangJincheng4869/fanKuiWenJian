import { SpIconName } from "@/components/icon/types";

/**
 * 前端菜单数据
 */
export interface LayoutMenu {
  /**
   * 唯一主键id
   */
  id: number
  /**
   * 上级id
   */
  parentId: number
  /**
   * 菜单名称
   */
  menuName: string
  /**
   * 是否使用浏览器新窗口打开 0-是 1-否
   */
  isBlank: number
  /**
   * 是否使用 iframe 打开， 0-是 1-否
   */
  isIframe: number
  /**
   * 菜单的唯一标识id，关系到能否正确打开Tab页，切记不可重复
   * 列名:data_id 类型:VARCHAR(32) 允许空:true 缺省值:null
   */
  dataId: string;
  /**
   * 图标
   */
  icon?: SpIconName
  /**
   * 路由地址，或外链地址
   */
  url: string
  /**
   * 菜单子项
   */
  children?: LayoutMenu[]

}