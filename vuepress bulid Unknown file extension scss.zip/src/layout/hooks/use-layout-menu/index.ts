import { LayoutMenu } from "@/layout/hooks/use-layout-menu/types";
import { useMenuStore } from "@/store/menu";
import { storeToRefs } from "pinia";

class UseLayoutMenu {

  /**
   * 添加菜单数据
   * @param menus 菜单数据数组
   */
  pushAllMenus(menus: LayoutMenu[]) {
    // 将数据转换为map备用
    const tempMenuMap = new Map<number, LayoutMenu>();
    menus.forEach(menu => {tempMenuMap.set(menu.id, menu)})
    // 将集合转为嵌套
    const tempMenu: LayoutMenu[] = []
    menus.forEach(menu => {
      // 查找该菜单的父菜单
      const pMenu = tempMenuMap.get(menu.parentId);
      // 如果找到了父菜单则需要添加到父菜单的 children 中
      if (pMenu) {
        if (pMenu.children) {
          pMenu.children.push(menu)
        } else {
          pMenu.children = [menu]
        }
      } else {
        // 如果没有找到父菜单，则是根菜单。直接加入数组
        tempMenu.push(menu)
      }
    })
    useMenuStore().menus.splice(0)
    useMenuStore().menus.push(...tempMenu)
  }

  /**
   * 通过dataId获取菜单-只能获取到一级菜单
   * @param dataId
   */
  public getMenu(dataId: string){
    return this.getMenuStoreRefs().menuMap.value.get(dataId)
  }

  /**
   * 获取响应式的 store
   */
  private getMenuStoreRefs(){
    return storeToRefs(useMenuStore());
  }
}

export const useLayoutMenu = new UseLayoutMenu();