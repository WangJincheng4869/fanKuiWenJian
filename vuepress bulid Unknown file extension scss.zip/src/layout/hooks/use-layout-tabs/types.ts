/**
 * 当前选中的标签数据
 */
export interface LayoutActiveTab {
  /**
   * 选中标签页的 id
   */
  id: string,
  /**
   * 当前选中标签页的 index
   */
  index: number
  /**
   * 激活的菜单id。index-0 需要选中的一级菜单，index-1 需要选中的二级菜单(一般二级菜单没有url则显示为分组) index-2 需要选中的二级菜单(当存在分组的时候，这才是真正的二级菜单)
   */
  activeMenuBreadcrumb: string[]
}