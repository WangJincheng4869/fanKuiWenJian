import { storeToRefs } from "pinia";
import { useLayoutTabsStore } from "@/store/layout-tabs";
import { LayoutTabsNavItem } from "@/layout/components/tabs-header/types";
import { Ref } from "vue";
import { useElementBounding, useWindowSize } from "@vueuse/core";
import { LocationQueryRaw, RouteParamsRaw, RouteRecordName } from "vue-router";

class UseLayoutTabs {

  private scrollbarRef = ref();

  /**
   *
   * @param id 唯一的标签页 id
   * @param name 标签页名称
   * @param path 标签页路径
   * @param isIframe 是否为 iframe，默认：false
   * @param closable 是否支持关闭，默认：true
   * @param silentOpen 静默打开，不直接显示当前页面，只是将页面打开，路由地址不变，默认：false
   * @param activeMenuBreadcrumb 激活的菜单id。index-0 需要选中的一级菜单，index-1 需要选中的二级菜单(一般二级菜单没有url则显示为分组) index-2 需要选中的二级菜单(当存在分组的时候，这才是真正的二级菜单)
   */
  public openTab(id: string, name: string, path: string, isIframe = false, closable = true, silentOpen = false, activeMenuBreadcrumb: number[] = []) {
    const length = useLayoutTabsStore().tabs.length;
    for (let i = 0; i < length; i++) {
      const tab = useLayoutTabsStore().tabs[i];
      // 已经存在，则默认选中当前选项卡
      if (tab.id === id) {
        this.activeTab(id, i)
        this.scrollTabVisible(id)
        return
      }
    }
    // 新的标签页对象
    const newTab: LayoutTabsNavItem = {
      id,
      name,
      closable,
      isIframe,
      activeMenuBreadcrumb: activeMenuBreadcrumb
    };
    // 当前选中标签的 index
    let activeTabIndex: number;
    // 判断是在哪里打开标签页
    if (useSetting.getSetting().newTabOpenType === 1) {
      activeTabIndex = useLayoutTabsStore().tabs.push(newTab) - 1
    } else {
      // 在当前选中标签之后打开
      activeTabIndex = useLayoutTabsStore().activeTab.index + 1
      useLayoutTabsStore().tabs.splice(activeTabIndex, 0, newTab)
    }
    // 判断是否未静默打开，如果非静默打开，则直接选中当前 tab
    if (!silentOpen) {
      this.activeTab(id, activeTabIndex)
      // 如果标签页不存在，则需要dom刷新后再执行滚动操作
      nextTick(() => {
        this.scrollTabVisible(id)
      })
    }
  }

  /**
   * 更新第一个标签
   * @param id 标签id
   * @param name 标签名称
   * @param routerName 路由名称
   * @param params 路由路径参数
   * @param query 路由参数 ?传参的参数
   */
  public updateFirstTab(id: string, name: string, routerName: RouteRecordName, params?: RouteParamsRaw, query?: LocationQueryRaw) {
    const tabsRefs = this.getTabsRefs();
    tabsRefs.value[0].id = id
    tabsRefs.value[0].name = name
    tabsRefs.value[0].routerName = routerName
    tabsRefs.value[0].params = params
    tabsRefs.value[0].query = query
  }

  /**
   * 关闭 tab 页
   * @param id tab 的唯一 id
   */
  public closeTab(id: string) {
    const length = useLayoutTabsStore().tabs.length;
    for (let i = 0; i < length; i++) {
      const tab = useLayoutTabsStore().tabs[i];
      // 已经存在，则默认选中当前选项卡
      if (tab.id === id) {
        // 如果关闭的是当前标签页，那么则需要选中上一个标签页
        if (useLayoutTabsStore().activeTab.id === id) {
          let activeTabId = useLayoutTabsStore().tabs[i - 1].id;
          this.activeTab(activeTabId, i - 1);
        } else if (i < useLayoutTabsStore().activeTab.index) {
          // 如果不是则判断关闭的标签是否在选中之前，如果是则选中标签 index - 1
          useLayoutTabsStore().activeTab.index = useLayoutTabsStore().activeTab.index - 1
        }
        // 删除当前标签
        useLayoutTabsStore().tabs.splice(i, 1)
        // 将保存的 ref 删除
        useLayoutTabsStore().tabRefs.delete(id)
        return
      }
    }
  }

  /**
   * 保存 tab Ref
   * @param id Tab 唯一 id
   * @param el tab Ref
   */
  public addTabRef(id: string, el: Ref<HTMLInputElement>) {
    useLayoutTabsStore().tabRefs.set(id, el);
  }

  /**
   * 选中 tab
   * @param id Tab 唯一 id
   * @param index Tab 当前处于的位置
   */
  public activeTab(id: string, index: number) {
    useLayoutTabsStore().activeTab.id = id
    useLayoutTabsStore().activeTab.index = index
  }

  /**
   * 返回响应式对象 activeTab
   */
  public getActiveTabRefs() {
    return this.getTabsStoreRefs().activeTab
  }

  /**
   * 返回响应式对象 tabs
   */
  public getTabsRefs() {
    return this.getTabsStoreRefs().tabs;
  }

  /**
   * 返回响应式对象 当前滚动条距左距离
   */
  public getNowScrollLeftRefs() {
    return this.getTabsStoreRefs().nowScrollLeft;
  }

  /**
   * 设置滚动条 Ref
   * @param ref 滚动条 Ref 对象
   */
  public setTabsScrollbarRef(ref: Ref) {
    this.scrollbarRef = ref;
  }

  /**
   * 根据访问目录查询tab对象
   * @param routerName 路由名称
   */
  public getTabByRouterName(routerName: RouteRecordName) {
    return useLayoutTabsStore().tabRouterNameMap.get(routerName)
  }

  /**
   * 根据 id 获取 tab 的 index
   * @param id tab 的 id
   */
  public getIndexById(id: string) {
    return useLayoutTabsStore().tabIndexMap.get(id)
  }

  /**
   * 获取响应式的 store
   */
  private getTabsStoreRefs() {
    return storeToRefs(useLayoutTabsStore());
  }

  /**
   * 滚动 tab 为可见的
   * @param id tab 的唯一 id
   */
  private scrollTabVisible(id: string) {
    const activeTabRef = useLayoutTabsStore().tabRefs.get(id);
    // 如果 tab 不存在就结束滚动操作
    if (!activeTabRef) return;
    const {left} = useElementBounding(activeTabRef);
    const {width} = useWindowSize()
    const nowScrollLeft = this.getNowScrollLeftRefs();
    let tabWidth = activeTabRef?.value.offsetWidth ?? 100
    if (left.value < 0) {
      // 当标签距左小于0时，那么如果想滚动到可视部分，则需要向右移动 标签页距左距离 + 菜单和logo的宽度（这里我们多滚动 10 像素）
      let scrollLeft = nowScrollLeft.value - (252 - left.value + 10)
      this.transitionScrollLeft(nowScrollLeft.value, nowScrollLeft.value, scrollLeft)
    } else if (left.value < 252) {
      // 当标签距左大于0小于菜单和logo的宽度时，那么如果想滚动到可视部分，则需要向右移动 标签页距左距离（这里我们多滚动 10 像素）
      let scrollLeft = nowScrollLeft.value - (left.value + 10)
      this.scrollbarRef.value.setScrollLeft(scrollLeft < 0 ? 0 : scrollLeft)
      this.transitionScrollLeft(nowScrollLeft.value, nowScrollLeft.value, scrollLeft)
    } else if (left.value + tabWidth > width.value) {
      // 当标签距左距离大于屏幕宽度时，说明在右侧隐藏。那么如果想滚动到可视部分，则需要向左移动 标签页距左距离 - 屏幕宽度 + 当前标签页的宽度
      let scrollLeft = nowScrollLeft.value + (left.value - width.value) + tabWidth
      this.transitionScrollLeft(nowScrollLeft.value, nowScrollLeft.value, scrollLeft)
    }
  }

  /**
   * 平滑滚动滚动条
   * @param nowScrollLeft 滚动条实时的距左距离
   * @param from 初始距左距离
   * @param to 滚动至距左距离
   * @private
   */
  private transitionScrollLeft(nowScrollLeft: number, from: number, to: number) {
    const offset = to - from;
    let scrollLeft = nowScrollLeft + offset / 30;
    if (offset > 0) {
      // 如果大于0则代表是向右滚动滚动条，需要增加距左距离到 to 的值
      this.scrollbarRef.value.setScrollLeft(scrollLeft < to ? scrollLeft : to)
      if (scrollLeft < to) {
        setTimeout(() => {
          this.transitionScrollLeft(scrollLeft, from, to)
        }, 1)
      }
    } else {
      // 如果小于0则代表是向左滚动滚动条，需要减少左距离到 to 的值
      this.scrollbarRef.value.setScrollLeft(scrollLeft > to ? scrollLeft : to)
      if (scrollLeft > to) {
        setTimeout(() => {
          this.transitionScrollLeft(scrollLeft, from, to)
        }, 1)
      }
    }
  }
}

export const useLayoutTabs = new UseLayoutTabs();