/**
 * 用户信息数据
 */
export interface UserDetails {
  /**
   * 工号
   */
  employeeNumber: string;

  /**
   * 员工姓名
   */
  employeeName: string;

  /**
   * 昵称，webcall对外显示
   */
  nickName?: string;

  /**
   * 员工头像地址，内部系统显示
   */
  profilePhoto?: string;

  /**
   * 员工头像地址，webcall系统使用
   */
  webcallProfilePhoto?: string;

  /**
   * 邮箱
   */
  email?: string;

  /**
   * 联系电话
   */
  tel?: string;

  /**
   * QQ号
   */
  qq?: string;

  /**
   * 微信号
   */
  wechat?: string;

  /**
   * 部门名称
   */
  departmentName: string;
}

/**
 * 用户技能信息
 */
export interface UserSkill {
  /**
   * 技能类型
   */
   skillTypeId: number;

  /**
   * 技能名称
   */
   skillName: string;

  /**
   * 技能编号，在使用中主要依赖技能编号
   */
   skillCode: string;
}