import { UserDetails, UserSkill } from "@/layout/hooks/use-user/types";
import { useUserStore } from "@/store/user";

class UseUser {
  /**
   * 插入用户缓存
   * @param userDetails 用户信息
   * @param userSkills 用户技能
   */
  setUser(userDetails: UserDetails, userSkills: UserSkill[]) {
    useUserStore().userDetails = userDetails
    useUserStore().userSkills.splice(0)
    useUserStore().userSkills.push(...userSkills)
  }

  /**
   * 当前用户是否拥有某个权限
   * @param skillCode 技能编码
   */
  hasAuth(skillCode: string) {
    return useUserStore().isAdministrator || useUserStore().skillCodes.has(skillCode)
  }
}

export const useUser = new UseUser();