import { TokenDTO } from "@/hooks/use-auth/types";
import { LayoutMenu } from "@/layout/hooks/use-layout-menu/types";
import { UserDetails, UserSkill } from "@/layout/hooks/use-user/types";

/**
 * 登录接口返回的数据
 */
export interface LoginDTO {
  /**
   * token 对象
   */
  token: TokenDTO;

  /**
   * 用户全部菜单数据
   */
  menus: LayoutMenu[];

  /**
   * 当前用户的全部技
   */
  skills: UserSkill[];

  /**
   * 当前用户信息
   */
  userDetails: UserDetails;
}