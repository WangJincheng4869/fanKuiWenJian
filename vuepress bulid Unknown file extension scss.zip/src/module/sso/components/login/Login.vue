<script setup lang="ts">
import LanguageSelect from "@/components/language/LanguageSelect.vue";
import router from "@/router";
import { JSEncrypt } from "jsencrypt";
import { useAuthStore } from "@/store/auth";
import { LoginDTO } from "@/module/sso/components/login/types";
import { useLayoutMenu } from "@/layout/hooks/use-layout-menu";
import { useUser } from "@/layout/hooks/use-user";
import ThemeSelect from "@/components/theme/ThemeSelect.vue";

const encrypt = new JSEncrypt();

// 获取加密 key
ajaxSso.get<string>('sso_auth/get_public_key').then(result => {
  if (result.status === ResultStatusEnum.SUCCESS) {
    encrypt.setPublicKey(result.data)
  } else if (result.status === ResultStatusEnum.ERROR_SYSTEM) {
    msgUtils.error(result.msg)
  } else {
    msgUtils.warning(result.msg)
  }
})

const logging = ref(false);

const loginFrom = reactive({
  username: '',
  password: '',
  captcha: '',
})

const login = () => {
  logging.value = true
  ajaxSso.postRawJson<LoginDTO>(`sso_auth/login`, {
    username: encrypt.encrypt(loginFrom.username),
    password: encrypt.encrypt(loginFrom.password),
    captcha: loginFrom.captcha,
  }).then(result => {
    if (result.status === ResultStatusEnum.SUCCESS) {
      // 获取token成功，将token存入sessionStorage中
      useAuth.updateToken(result.data.token)
      useLayoutMenu.pushAllMenus(result.data.menus)
      useUser.setUser(result.data.userDetails, result.data.skills)
      router.push({
        path: useAuthStore().loginRedirectUrl
      })
      useAuth.resetLoginRedirectUrl()
    } else if (result.status === ResultStatusEnum.ERROR_SYSTEM) {
      msgUtils.error(result.msg)
      logging.value = false;
    } else {
      msgUtils.warning(result.msg)
      logging.value = false;
    }
  }).catch((e) => {
    console.error(e)
    logging.value = false;
    msgUtils.error('连接服务器失败！请稍后再试')
  })
}
</script>

<template>
  <div class="fixed right-5 top-5">
    <theme-select />
    <language-select class="ml-4"/>
  </div>
  <div style="width: 500px;margin: 100px auto 0;">
    <el-form v-model="loginFrom" label-width="150px">
      <el-form-item :label="$t('employee.employeeName')" prop="username">
        <el-input v-model="loginFrom.username" maxlength="32"/>
      </el-form-item>
      <el-form-item :label="$t('employee.password')" prop="password">
        <el-input v-model="loginFrom.password" type="text" show-password maxlength="18"/>
      </el-form-item>
    </el-form>
    <el-button class="w-full" @click="login" :loading="logging">{{ logging ? $t('loading.momentPlease') : $t('btn.login') }}</el-button>
  </div>
</template>

<style scoped>
</style>