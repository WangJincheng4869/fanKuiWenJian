import { RouteRecordRaw } from "vue-router";
import { TargetEnum } from "@/router/types";

export default [
  {
    path: '/ticket',
    name: 'ticket',
    component: () => import("@/module/ticket/components/TicketInfo.vue"),
    meta: {
      title: 'ticket',
      target: TargetEnum.NEW_TAB
    }
  }, {
    path: '/ticket1',
    name: 'ticket1',
    component: () => import("@/module/ticket/components/TicketInfo1.vue"),
    meta: {
      title: 'ticket1',
      target: TargetEnum.NEW_TAB
    }
  }
] as Array<RouteRecordRaw>