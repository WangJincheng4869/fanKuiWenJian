<script setup lang="ts">
import { MaybeElementRef, MaybeRefOrGetter, useColorMode } from '@vueuse/core';
import { ThemeDefaultConsts } from "@/components/theme/theme-default-consts";

interface Props {
  /**
   * 下拉框的大小
   *
   * @default 'default'
   */
  size?: "" | "default" | "small" | "large"
  /**
   * 将数据持久化到 localStorage/sessionStorage 的 key。传递 null 以禁用持久性
   *
   * @default 'basic-paper-cloud-color-scheme'
   */
  storageKey?: string
  /**
   * CSS Selector for the target element applying to
   *
   * @default 'html'
   */
  selector?: string | MaybeElementRef
  /**
   * HTML attribute applying the target element
   *
   * @default 'class'
   */
  attribute?: string

}

const props = withDefaults(defineProps<Props>(), {
  size: "default",
  storageKey: ThemeDefaultConsts.STORAGE_KEY,
})

// 主题模式
const {store} = useColorMode({
  storageKey: props.storageKey,
  selector: props.selector,
  attribute: props.attribute
});
</script>

<template>
  <el-select v-model="store" :size="props.size">
    <el-option value="auto" :label="$t('theme.auto')"/>
    <el-option value="dark" :label="$t('theme.dark')"/>
    <el-option value="light" :label="$t('theme.light')"/>
  </el-select>
</template>