/**
 * 主题默认配置常量
 */
export class ThemeDefaultConsts {
  /**
   * 主题色存储 key
   */
  static readonly STORAGE_KEY = 'basic-paper-cloud-color-scheme'
}
