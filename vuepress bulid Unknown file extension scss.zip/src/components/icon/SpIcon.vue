<script setup lang="ts">
import { SpIconName } from "@/components/icon/types";
import UnknownAnimate from "../../assets/svg/unknown-animate.svg?component"

interface Props {
  /**
   * 图标名称
   */
  name: SpIconName;
}

const props = withDefaults(defineProps<Props>(), {
  name: "unknown-animate"
})

// noinspection TypeScriptCheckImport
let Icon = defineAsyncComponent({
  loader: () => import(`../../assets/svg/${props.name}.svg?component`),
  errorComponent: UnknownAnimate
});

</script>

<template>
  <i class="sp-icon">
    <icon />
  </i>
</template>

<style lang="scss">
.sp-icon {
  --color: inherit;
  height: 1em;
  width: 1em;
  line-height: 1em;
  display: inline-flex;
  justify-content: center;
  align-items: center;
  position: relative;
  fill: currentColor;
  color: var(--color);
  font-size: inherit;

  svg {
    height: 1em;
    width: 1em;
  }
}
</style>