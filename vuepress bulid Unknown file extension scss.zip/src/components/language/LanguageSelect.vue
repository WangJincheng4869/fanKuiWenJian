<script setup lang="ts">
import Language from "@/assets/svg/language.svg?component";
import {i18nUtils} from "@/config/i18n";
import {useI18n} from "vue-i18n";

const {switchI18n, locales} = i18nUtils();
// 当前的语言
const {locale} = useI18n()

</script>

<template>
  <el-dropdown trigger="click">
    <language class="w-5 h-5 hover:text-primary cursor-pointer outline-none"/>
    <template #dropdown>
      <el-dropdown-menu>
        <template v-for="(value, key) in locales" :key="key">
          <el-dropdown-item :class="{'hidden': locale === key}" @click="switchI18n(key)">{{ value }}</el-dropdown-item>
        </template>
      </el-dropdown-menu>
    </template>
  </el-dropdown>
</template>