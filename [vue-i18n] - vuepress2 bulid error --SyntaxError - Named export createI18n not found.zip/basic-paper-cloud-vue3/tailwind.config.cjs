/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ['./index.html', './src/**/*.{vue,js,ts}'],
  theme: {
    extend: {
      colors: {
        primary: "var(--el-color-primary)",
      }
    },
  },
  plugins: [],
  corePlugins: {
    // 禁用响应式容器功能，即container类
    container: false,
  }
}
