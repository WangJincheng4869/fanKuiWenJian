import {defineConfig} from "vite";
import vue from "@vitejs/plugin-vue";
import {compression} from "vite-plugin-compression2";
import {resolve} from "path";
import VueI18nPlugin from "@intlify/unplugin-vue-i18n/vite";
import AutoImport from "unplugin-auto-import/vite";
import Components from "unplugin-vue-components/vite";
import {ElementPlusResolver} from "unplugin-vue-components/resolvers";
// @ts-ignore
import ElementPlus from 'unplugin-element-plus/vite';
import svgLoader from "vite-svg-loader";

// https://vitejs.dev/config/
export default defineConfig({
  server: {
    host: "0.0.0.0",
  },
  resolve: {
    alias: {
      "@": resolve(__dirname, "./src"),
    },
  },
  css: {
    preprocessorOptions: {
      scss: {
        additionalData: `@use "@/styles/element/index.scss" as *;`,
      },
    },
  },
  plugins: [
    vue(),
    // https://github.com/jpkleemans/vite-svg-loader
    svgLoader(),
    // https://github.com/element-plus/unplugin-element-plus
    ElementPlus({
      useSource: true,
    }),
    // https://github.com/antfu/unplugin-auto-import
    AutoImport({
      imports: [
        'vue',
      ],
      dirs: [
        'src/util/**',
        'src/hooks/**',
      ],
      dts: 'types/auto-imports.d.ts',
      resolvers: [
        ElementPlusResolver({
          importStyle: "sass",
        }),
      ],
    }),
    // https://github.com/antfu/unplugin-vue-components
    Components({
      // 只用ElementPlus的按需导入，故不扫描自己的项目文件
      dirs: [],
      dts: "types/components.d.ts",
      resolvers: [
        ElementPlusResolver({
          importStyle: "sass",
        }),
      ],
    }),
    // https://github.com/intlify/bundle-tools/tree/main/packages/vite-plugin-vue-i18n
    VueI18nPlugin({
      runtimeOnly: true,
      compositionOnly: true,
      include: [resolve("locale/**")],
    }),
    compression({exclude: [/\.(br)$/, /\.(gz)$/]}),
    compression({algorithm: "brotliCompress", exclude: [/\.(br)$/, /\.(gz)$/]}),
  ],
});
