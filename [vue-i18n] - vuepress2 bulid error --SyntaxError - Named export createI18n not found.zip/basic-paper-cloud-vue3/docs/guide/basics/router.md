---
title: 前端路由
author: 王金城
---

前端框架路由使用的是 [Vue Router](https://router.vuejs.org/zh/)，主路由配置在`src/router/index.ts`中，在这个文件中我们只配置主框架中的路由，各个模块的路由需要在各自模块中配置。

## 模块路由文件规则

路由分为`独立页面路由`和`主页面子路由`之分。

独立页面路由：顾名思义，就是打开会占用整个页面的路由。如：登录页面、CCView监控页面等；

主页面子路由：顾名思义，就是在主页面内以tab页模式打开打开子页面的路由。如：工单页面、配置页面等；

### 独立页面路由

需要放在具体模块目录下，如：`src/module/sso/router/index.ts`。

```ts
import {RouteRecordRaw} from "vue-router";

export default [
  {
    path: '/login',
    name: 'LoginPage',
    component: import('@/module/sso/components/Login.vue')
  }
] as Array<RouteRecordRaw>
```

### 主页面子路由

需要放在具体模块目录下，如：`src/module/ticket/router/children-*.ts`，其中的`*`可以使用模块的名称`children-router-ticket.ts`，也可以直接起名为`children-router.ts`

```ts
import {RouteRecordRaw} from "vue-router";

export default [
  {
    path: '/ticket',
    name: 'ticket',
    component: () => import("@/module/ticket/components/TicketInfo.vue"),
    meta: {}
  }
] as Array<RouteRecordRaw>
```

## 路由页面保活

在日常使用中，用户会打开多个tab页，所以就需要将路由页面进行保活操作。我们使用Vue的内置组件 [KeepAlive](https://cn.vuejs.org/guide/built-ins/keep-alive.html#basic-usage)
实现的此功能。只需在路由的`meta`参数中配置上`keepAlive:true`即可

```ts {8-10}
import {RouteRecordRaw} from "vue-router";

export default [
  {
    path: '/ticket',
    name: 'ticket',
    component: () => import("@/module/ticket/components/TicketInfo.vue"),
    meta: {
      keepAlive: true
    }
  }
] as Array<RouteRecordRaw>
```

## 将 props 传递给路由组件

这是 [Vue Router](https://router.vuejs.org/zh/) 的基础功能，就是利用路由的`props`将参数传给组件的`props`，下面只介绍`函数模式`
的使用，因为它可以实现混合传输，更加灵活。如果想了解更多可以移步官方文档[查看详情](https://router.vuejs.org/zh/guide/essentials/passing-props.html)

### 函数模式

你可以创建一个返回 props 的函数。这允许你将参数转换为其他类型，将静态值与基于路由的值相结合等等。

```ts {5-8}
const routes: RouteRecordRaw[] = [{
  path: "/work-order/work-order-info/:orderCode",
  name: "orderInfo",
  component: WorkOrderInfo,
  props: route => ({
    orderCode: route.params.orderCode,
    urgeCoid: route.query.urgeCoid
  })
}]

```

URL `/work-order/work-order-info/ZX20180001?urgeCoid=coid20180001` 将传递 `{orderCode: 'ZX20180001', urgeCoid: 'coid20180001'}` 作为 props 传给 `WorkOrderInfo` 组件。

:::tip

1. `route => ({})` 这个箭头函数外面包了一个括号是因为要返回对象类型，是固定的语法规则。可以查看 MDN
   箭头函数文档 —— [返回对象字面量](https://developer.mozilla.org/zh-CN/docs/Web/JavaScript/Reference/Functions/Arrow_functions#%E8%BF%94%E5%9B%9E%E5%AF%B9%E8%B1%A1%E5%AD%97%E9%9D%A2%E9%87%8F)
2. `route.params` 是提取路径参数。`route.query` 是提取 URL 中 `?` 传输的参数。可以在官方 API 中查看 [params](https://router.vuejs.org/zh/api/#params)
   和 [query](https://router.vuejs.org/zh/api/#query) 的详细信息

:::

在组件中创建接收数据的 props

```ts {2-3}
const props = defineProps({
  orderCode: String,
  urgeCoid: String
})
```

