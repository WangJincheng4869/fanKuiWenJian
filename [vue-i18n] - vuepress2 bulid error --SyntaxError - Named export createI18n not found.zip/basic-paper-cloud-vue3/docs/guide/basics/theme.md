---
title: 主题和暗黑模式
author: 王金城
---

目前框架内置了明亮和暗黑两种主题，采用 VueUse 中的 [useColorMode](https://vueuse.org/core/useColorMode/) 获取当前系统模式和切换主题功能。

## 开发注意事项

1. 窗格背景色尽量不要手动设置，如果存在特殊样式，那么需要使用变量，并兼顾暗黑模式的切换
2. 在开发自定义组件时，需要兼顾两种主题色
3. 尽量使用 [Element Plus](https://element-plus.org/zh-CN/) 组件库中的组件，因为我们已经配置了组件库的暗黑模式
4. 尽量不要使用自定义颜色，统一使用 [Element Plus](https://element-plus.org/zh-CN/) 中定义的颜色变量

## 内置组件

### ThemeSelect 主题切换选择器

这个组件一般用于系统设置页面，可以设置当前主题为自动模式，可以获取系统的情况自动变更主题。您可以简单体验一下这个组件，也可以到组件页了解详情。

<theme-ThemeSelect storageKey="vuepress-theme-hope-scheme"/>

### ThemeSwitch 主题切换

这个组件只能进行明亮主题和暗黑主题的切换。您可以简单体验一下这个组件，也可以到组件页了解详情。

<theme-ThemeSwitch storageKey="vuepress-theme-hope-scheme"/> 