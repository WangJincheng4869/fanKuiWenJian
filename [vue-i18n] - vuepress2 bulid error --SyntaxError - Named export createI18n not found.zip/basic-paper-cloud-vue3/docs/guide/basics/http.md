---
title: 前端 http 请求
author: 王金城
---

前端平台对 [Axios](https://www.axios-http.cn/) 进行了封装，支持的请求方式与高级使用方法请看 [Axios API](https://www.axios-http.cn/docs/api_intro)。

## 实现自己模块的工具类

由于`axios`需要设置`baseURL`。但是不同的模块的`baseURL`可能不同。所以为了方便使用，框架中封装了一个抽象类`BaseAjaxUtils`，在`src/util/http/ajax-utils.ts`中。需要在`src/util/http/impl`
目录下实现各自模块的工具类，下面以`sso-ajax-utils.ts`为例

```ts
import {BaseAjaxUtils} from "@/util/http/ajax-utils";
import axios from "axios";

class SsoAjaxUtils extends BaseAjaxUtils {
  instance = axios.create({
    baseURL: apiBaseUrl.sso
  })

  constructor() {
    super();
  }
}

export const ajaxSso = new SsoAjaxUtils();
```

## 使用工具类

我们以最常用的`postRawJson`方法为例

```ts
ajaxSso.postRawJson(`/sso_auth/web/login`, {
  username: 'username',
  password: 'password',
}).then(result => {
  if (result.status === ResultStatusEnum.SUCCESS) {
    // 这里写请求成功的操作
  } else if (result.status === ResultStatusEnum.ERROR_SYSTEM) {
    msgUtils.error(result.msg)
  } else {
    msgUtils.warning(result.msg)
  }
}).catch(() => {
// 这里可以自定义你的异常处理
})
```
