---
title: 前端框架目录结构
author: 王金城
---

```
├─ .vscode    # VS Code 推荐配置文件
├─ docs    # 文档程序主目录，文档的内容全部在这个目录下
│  ├─ .vuepress    # VuePress 相关的文件
│  │  ├─ .cache    # 缓存目录（忽略版本控制，即：不要提交到 SVN 或 git）
│  │  ├─ .temp    # 临时目录（忽略版本控制，即：不要提交到 SVN 或 git）
│  │  ├─ configs    # VuePress 文档配置目录
│  │  │  ├─ navbar.ts    # 导航栏配置文件
│  │  │  └─ sidebar.ts    # 侧边栏配置配置文件
│  │  ├─ public    # 文档静态资源目录
│  │  ├─ styles    # 主题样式文件
│  │  └─ config.ts    # VuePress 站点的基本配置文件
│  ├─ guide    # 指南页目录
│  └─ README.md    # 文档主页
├─ locale    # 多语言翻译文件目录
│  ├─ en.yml    # 英文翻译文件
│  └─ zh-CN.yml    # 中文翻译文件
├─ node_modules    # 模块依赖
├─ public    # 静态资源
│  └─ application-config.js    # 项目配置文件
├─ src    # 
│  ├─ assets    # 字体、图片等静态资源，这个目录下的静态资源会进行打包处理
│  ├─ components    # 项目通用组件存储目录，一般为可以公用的组件工具
│  ├─ config    # 项目配置文件目录
│  ├─ hooks    # vue hooks 存储目录，它区别于组件，是拥有 vue 特性的工具类，比如使用到了生命周期、动态绑定等功能
│  ├─ layout    # 程序主框架布局，即 main 页面
│  ├─ module    # 程序子模块目录，例如：登录、工单、设置等模块。可以通过配置选择不打包哪些模块
│  ├─ router    # 主路由配置目录，这里仅仅是主路由配置。各个模块的路由需要放在 module/**/router/ 目录下
│  ├─ scheduled    # 项目全局定时任务目录。如子模块需要类似功能，且不通用，请在自己的模块下创建
│  ├─ store    # 项目全局 pinia 状态管理目录。如子模块需要类似功能，且不通用，请在自己的模块下创建
│  ├─ styles    # 项目全局样式目录。如子模块需要类似功能，且不通用，请在自己的模块下创建
│  ├─ util    # 项目全局工具类目录。如子模块需要类似功能，且不通用，请在自己的模块下创建
│  │  ├─ auth    # 鉴权工具类
│  │  ├─ feedback    # 反馈组件工具类
│  │  └─ http    # http 请求工具类
│  ├─ App.vue    # vue 入口页面
│  ├─ main.ts    # vue 入口文件
│  └─ vite-env.d.ts    # vite 声明文件
├─ types    # 项目全局声明文件目录
│  ├─ auto-imports.d.ts    # 自动导入插件全局声明文件，无需手动修改，项目启动会自动更新
│  ├─ components.d.ts    # vue组件自动导入插件全局声明文件，无需手动修改，项目启动会自动更新
│  ├─ global.d.ts    # 项目全局声明文件
│  └─ module-plugin.d.ts    # 项目全局声明文件，主要用于项目中依赖模块的声明合并
├─ .gitignore    # git 忽略提交配置
├─ index.html    # 页面入口文件
├─ package.json    # 依赖包管理以及命令配置
├─ pnpm-lock.yaml    # 依赖包版本锁定文件
├─ postcss.config.cjs    # postcss 插件配置
├─ README.md    # 项目介绍
├─ tailwind.config.cjs    # tailwindcss 配置
├─ tsconfig.json    # typescript 配置
├─ tsconfig.node.json    # typescript 配置
└─ vite.config.ts    # vite 配置
```