import { defineClientConfig } from '@vuepress/client'
import ElementPlus from 'element-plus'
import './styles/element/index.scss'
import { localesConfigs } from "../../src/config/i18n";
import { createI18n, I18n } from 'vue-i18n';

const i18n: I18n = createI18n({
  legacy: false,
  locale: "zh-CN",
  fallbackLocale: "zh-CN",
  messages: localesConfigs
});
export default defineClientConfig({
  enhance({app}) {
    app.use(ElementPlus).use(i18n)
  },
})