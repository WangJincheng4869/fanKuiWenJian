import {defineUserConfig, viteBundler} from "vuepress";
import {hopeTheme} from "vuepress-theme-hope";
import {searchPlugin} from "@vuepress/plugin-search";
import {sidebar} from "./configs/sidebar";
import {navbar} from "./configs/navbar";
import {registerComponentsPlugin} from '@vuepress/plugin-register-components'
import {resolve} from "path";
import svgLoader from "vite-svg-loader";
import VueI18nPlugin from "@intlify/unplugin-vue-i18n/vite";

export default defineUserConfig({
  host: "0.0.0.0",
  port: 5174,
  base: "/docs/",
  lang: "zh-CN",
  title: "BasicPaperCloud",
  description: "BasicPaperCloud 前后端分离开发文档",
  alias: {
    "@": resolve(__dirname, "../../src"),
    "@theme-hope/modules/outlook/components/AppearanceSwitch": resolve(__dirname, "./components/ThemeSwitch.vue"),
  },
  bundler: viteBundler({
    viteOptions: {
      plugins: [
        // @ts-ignore https://github.com/jpkleemans/vite-svg-loader
        svgLoader(),
        // @ts-ignore https://github.com/intlify/bundle-tools/tree/main/packages/vite-plugin-vue-i18n
        VueI18nPlugin({
          runtimeOnly: true,
          compositionOnly: true,
          include: [resolve(__dirname, "../../locale/**")],
        }),
      ]
    }
  }),
  theme: hopeTheme({
    navbar: navbar,
    sidebar: sidebar,
    lastUpdated: true,
    plugins: {
      copyCode: {
        showInMobile: true
      },
      autoCatalog: true,
    }
  }),
  plugins: [
    searchPlugin({
      locales: {
        "/": {
          placeholder: "搜索",
        },
      },
      // 排除首页
      isSearchable: (page) => page.path !== "/",
    }),
    registerComponentsPlugin({
      componentsDir: resolve(__dirname, '../../src/components'),
    })
  ],
});
