import {NavbarOptions} from "vuepress-theme-hope/lib/shared/navbar";

// 导航栏配置
export const navbar: NavbarOptions = [
  {
    text: '指南',
    link: '/guide/',
  }, {
    text: '组件',
    link: '/component/',
  }, {
    text: 'API',
    link: '/api/',
  }, {
    text: '规范',
    link: '/standards/',
  }
]