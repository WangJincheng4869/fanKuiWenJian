/**
 * 接口地址
 */
const apiBaseUrl = {
  // BP主模块
  bp: 'api/basic-paper-bp',
  // 登录模块
  sso: 'api/basic-paper-sso',
};