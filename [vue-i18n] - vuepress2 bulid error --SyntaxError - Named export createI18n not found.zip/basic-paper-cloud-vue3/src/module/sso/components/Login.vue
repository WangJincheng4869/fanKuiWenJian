<script setup lang="ts">
import LanguageSelect from "@/components/language/LanguageSelect.vue";
import ThemeSelect from "@/components/theme/ThemeSelect.vue";
import ThemeSwitch from "@/components/theme/ThemeSwitch.vue";

const v = ref()
const x = () => {
  msgBoxUtils.alert('啊啊啊')
  msgBoxUtils.alert('啊啊啊')
  ajaxSso.postRawJson(`/sso_auth/web/login`).then(result => {
    if (result.status === ResultStatusEnum.SUCCESS) {

    } else if (result.status === ResultStatusEnum.ERROR_SYSTEM) {
      msgUtils.error(result.msg)
    } else {
      msgUtils.warning(result.msg)
    }
  })
}
</script>

<template>
  <el-input v-model="v" :placeholder="$t('btn.save')" @click="x" />
  <span>{{ $t('btn.del') }}</span>
  <language-select />
  <theme-select />
  <theme-switch />
  <div style="height: 10000px"></div>
</template>

<style scoped>
.locale {
  width: 90px;
}
</style>