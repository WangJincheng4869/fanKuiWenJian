export interface ApiBaseUrl {
  /**
   * BP主程序请求接口地址
   */
  bp: string;
  /**
   * 单点登录请求接口地址
   */
  sso: string;
}