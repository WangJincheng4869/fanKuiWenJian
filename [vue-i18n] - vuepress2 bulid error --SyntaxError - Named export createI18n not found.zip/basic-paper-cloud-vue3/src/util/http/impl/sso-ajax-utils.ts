import {BaseAjaxUtils} from "@/util/http/ajax-utils";
import axios from "axios";

class SsoAjaxUtils extends BaseAjaxUtils {
  instance = axios.create({
    baseURL: apiBaseUrl.sso
  })

  constructor() {
    super();
  }
}

export const ajaxSso = new SsoAjaxUtils();