import axios, {AxiosInstance, AxiosRequestConfig} from "axios";
import {authUtils} from "../auth/auth-utils";
import router from "../../router";
import {i18n} from "@/config/i18n";
import {ResultVO} from "./ajax-types";

const {t} = i18n.global;

export abstract class BaseAjaxUtils {

  /**
   * Axios 实例，实现类可以重新此方法来创建自己的 baseURL
   * @protected
   */
  protected instance: AxiosInstance = axios.create();

  protected constructor() {
    // 添加请求拦截器
    this.instance.interceptors.request.use(
        function (config) {
          // 在发送请求之前将token存入header
          config.headers["Authorization"] = `Bearer ${authUtils.getAccessToken()}`;
          return config;
        },
        function (error) {
          // 对请求错误做些什么
          return Promise.reject(error);
        }
    );
    // 添加响应拦截器
    this.instance.interceptors.response.use(
        function (response) {
          // 请求成功直接提取接口返回的内容
          return response.data;
        },
        function (error) {
          try {
            if (error.response.status === 401) {
              // @ts-ignore
              msgUtils.warning(t("msg.warning.loginTimeoutReLogin"));
              router.replace({name: "Login"});
            } else if (error.response.status === 403) {
              // @ts-ignore
              msgUtils.warning(t("msg.warning.httpForbiddenContactAdministrator"));
              console.warn(`接口权限不足，请求url=${error.config.url}`);
            }
          } catch (e) {
            console.error(e, "axios异常拦截器处理异常，可以忽略此错误");
          }
          return Promise.reject(error);
        }
    );
  }

  /**
   * get请求
   * @param url 接口地址
   * @param params 参数对象
   * @param timeout 超时时间（毫秒）
   */
  public get(url: string, params?: any, timeout: number = 0): Promise<ResultVO> {
    return this.instance.get(url, {
      params,
      timeout,
    });
  }

  /**
   * 表单形式使用post请求提交数据到服务端
   * @param url 接口地址
   * @param params 参数对象
   * @param config 配置信息
   */
  public post(url: string, params?: any, config?: AxiosRequestConfig): Promise<ResultVO> {
    const formData = new FormData();
    for (const paramsKey in params) {
      formData.append(paramsKey, params[paramsKey]);
    }
    return this.instance.post(url, formData, config);
  }

  /**
   * 表单形式使用post请求提交数据到服务端，可提交文件并可监听文件上传进度
   * @param url 接口地址
   * @param params 参数对象
   * @param onUploadProgress 文件上传进度事件
   */
  public postFile(url: string, params?: any, onUploadProgress?: (progressEvent: any) => void): Promise<ResultVO> {
    const formData = new FormData();
    for (const paramsKey in params) {
      formData.append(paramsKey, params[paramsKey]);
    }
    return this.instance.post(url, formData, {
      onUploadProgress: function (evt) {
        if (onUploadProgress) onUploadProgress(evt);
      },
    });
  }

  /**
   * 使用raw模式将参数写在body中以JSON形式发给服务端
   * @param url 接口地址
   * @param params 接口参数对象
   */
  public postRawJson(url: string, params?: any): Promise<ResultVO> {
    return this.instance.post(url, params, {
      transformRequest: [
        //转化要传入的为字符串
        function (data) {
          return JSON.stringify(data);
        },
      ],
      headers: {
        "Content-Type": "application/json",
      },
    });
  }

  /**
   * 表单形式使用put请求提交数据到服务端
   * @param url 接口地址
   * @param params 参数对象
   * @param config 配置信息
   */
  public put(url: string, params?: any, config?: AxiosRequestConfig): Promise<ResultVO> {
    const formData = new FormData();
    for (const paramsKey in params) {
      formData.append(paramsKey, params[paramsKey]);
    }
    return this.instance.put(url, formData, config);
  }

  /**
   * 使用raw模式将参数写在body中以JSON形式发给服务端
   * @param url 接口地址
   * @param params 接口参数对象
   */
  public putRawJson(url: string, params?: any): Promise<ResultVO> {
    return this.instance.put(url, params, {
      transformRequest: [
        //转化要传入的为字符串
        function (data) {
          return JSON.stringify(data);
        },
      ],
      headers: {
        "Content-Type": "application/json",
      },
    });
  }

  /**
   * 表单形式删除数据
   * @param url 接口地址
   * @param params 接口参数对象
   * @param timeout 超时时间（毫秒）
   */
  public del(url: string, params?: any, timeout: number = 0): Promise<ResultVO> {
    return this.instance.delete(url, {params, timeout});
  }

  /**
   * 完整的请求，你可以进行自定配置
   * @param config 请求配置项，详见 {@link https://www.axios-http.cn/docs/req_config"}
   */
  public request(config: AxiosRequestConfig): Promise<ResultVO> {
    return this.instance.request(config);
  }
}

/**
 * Ajax工具类，这是没有baseURL的工具类
 */
class AjaxUtils extends BaseAjaxUtils {
  constructor() {
    super()
  }
}

export const ajax = new AjaxUtils();