import {AccessTokenDTO} from "./auth-types";
import {useAuthStore} from "@/store/auth";

class AuthUtils {

  /**
   * accessToken在session中存贮的key
   */
  private static readonly ACCESS_TOKEN_KEY = "accessToken";
  /**
   * accessToken过期的时间戳在session中存贮的key
   */
  private static readonly TOKEN_TIMEOUT_KEY = "tokenTimeout";
  /**
   * 用于记录用户访问被拦截到登录页面的url，用于登陆后的会跳
   */
  private static readonly REDIRECT_URL_KEY = "loginRedirectUrl";
  /**
   * token超时时间冗余值，差五分钟超时就算超时，需要重新获取token
   */
  private static readonly TOKEN_TIMEOUT_THRESHOLD = 1000 * 60 * 5;

  /**
   * 获取当前token是否超时，会优先从状态管理中获取
   */
  public isTimeout(): boolean {
    let tokenTimeout = useAuthStore().tokenTimeout;
    // 提前一分钟获取超时时间
    return tokenTimeout - Date.now() < AuthUtils.TOKEN_TIMEOUT_THRESHOLD
  }

  /**
   * 获取accessToken，会优先从状态管理中获取
   */
  public getAccessToken(): string {
    return useAuthStore().accessToken
  }

  /**
   * 获取sessionStorage中的accessToken，不建议直接使用，请使用getAccessToken()
   */
  public getSessionAccessToken(): string {
    return sessionStorage.getItem(AuthUtils.ACCESS_TOKEN_KEY) || ""
  }

  /**
   * 获取accessToken的过期时间戳
   */
  public getSessionTokenTimeout(): number {
    let tokenTimeout = sessionStorage.getItem(AuthUtils.TOKEN_TIMEOUT_KEY);
    if (tokenTimeout) {
      return parseInt(tokenTimeout)
    }
    return 0;
  }

  /**
   * 更新accessToken
   * @param accessTokenDTO 接口返回的accessToken对象
   */
  public updateToken(accessTokenDTO: AccessTokenDTO): void{
    sessionStorage.setItem(AuthUtils.ACCESS_TOKEN_KEY, accessTokenDTO.accessToken);
    sessionStorage.setItem(AuthUtils.TOKEN_TIMEOUT_KEY, String(accessTokenDTO.expiresIn + Date.now()));
    useAuthStore().$reset();
  }

  /**
   * 获取登录成功回调url
   */
  public getLoginRedirectUrl(): string {
    return sessionStorage.getItem(AuthUtils.REDIRECT_URL_KEY) || "";
  }

  /**
   * 设置登录成功回调url
   * @param url url
   */
  public setLoginRedirectUrl(url: string): void {
    sessionStorage.setItem(AuthUtils.REDIRECT_URL_KEY, url);
  }

  /**
   * 删除登录成功回调url，跳转后删除，防止出现脏数据。因为默认要进入程序首页
   */
  public removeLoginRedirectUrl(): void {
    sessionStorage.removeItem(AuthUtils.REDIRECT_URL_KEY)
  }

}

export const authUtils = new AuthUtils();