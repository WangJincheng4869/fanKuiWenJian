import {createApp} from 'vue'
import App from './App.vue'
import Router from "./router";
import './styles/tailwind.css'
import './styles/index.scss'
import ElementPlus from 'element-plus'
import {createPinia} from 'pinia'
import {authScheduled} from "./scheduled/auth-scheduled";
import {i18n} from "@/config/i18n";

const pinia = createPinia()
let app = createApp(App);
app.use(pinia);

app.use(Router).use(i18n).use(ElementPlus).mount('#app')
// 开启自动更新token定时任务
authScheduled.refreshToken()