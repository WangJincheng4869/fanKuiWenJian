<script setup lang="ts">
import { useColorMode } from '@vueuse/core';

interface Props {
  /**
   * 下拉框的大小
   *
   * @default 'default'
   */
  size?: "" | "default" | "small" | "large"
  /**
   * 将数据持久化到 localStorage/sessionStorage 的 key。传递 null 以禁用持久性
   *
   * @default 'basic-paper-cloud-color-scheme'
   */
  storageKey?: string
}

const props = withDefaults(defineProps<Props>(), {
  size: "default",
  storageKey: 'basic-paper-cloud-color-scheme'
})

// 主题模式
const mode = useColorMode({
  emitAuto: true,
  storageKey: props.storageKey
});

</script>

<template>
  <el-select v-model="mode" :size="props.size">
    <el-option value="auto" :label="$t('theme.auto')"/>
    <el-option value="dark" :label="$t('theme.dark')"/>
    <el-option value="light" :label="$t('theme.light')"/>
  </el-select>
</template>