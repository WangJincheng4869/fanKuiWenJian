<script setup lang="ts">
import {useColorMode} from '@vueuse/core';
import SunnyFilled from '@/assets/svg/sunny-filled.svg?component'
import MoonFatFilled from '@/assets/svg/moon-fat-filled.svg?component'

interface Props {
  /**
   * 将数据持久化到 localStorage/sessionStorage 的 key。传递 null 以禁用持久性
   *
   * @default 'basic-paper-cloud-color-scheme'
   */
  storageKey?: string
}

const props = withDefaults(defineProps<Props>(), {
  storageKey: 'basic-paper-cloud-color-scheme'
})

// 主题模式
const mode = useColorMode({
  storageKey: props.storageKey
});

</script>

<template>
  <div class="theme-switch-box">
    <div class="theme-switch" role="switch" @click="mode === 'dark' ? mode = 'light' : mode = 'dark'">
      <div class="switch__action">
        <div class="switch__icon">
          <sunny-filled class="dark-icon"/>
          <moon-fat-filled class="light-icon"/>
        </div>
      </div>
    </div>
  </div>
</template>

<style scoped lang="scss">
.theme-switch-box {
  --bg-color-mute: #f2f2f2;
  display: inline;

  .theme-switch {
    margin: 0;
    display: inline-block;
    position: relative;
    width: 40px;
    height: 20px;
    border: 1px solid var(--el-border-color);
    outline: none;
    border-radius: 10px;
    box-sizing: border-box;
    background: var(--bg-color-mute);
    cursor: pointer;
    transition: border-color var(--el-transition-duration), background-color var(--el-transition-duration);

    .switch__action {
      position: absolute;
      top: 1px;
      left: 1px;
      width: 16px;
      height: 16px;
      border-radius: 50%;
      background-color: var(--el-bg-color);
      transform: translate(0);
      color: var(--el-text-color-regular);
      transition: border-color var(--el-transition-duration), background-color var(--el-transition-duration), transform var(--el-transition-duration);

      .switch__icon {
        width: 14px;
        height: 14px;
        line-height: 14px;
        display: inline-flex;
        justify-content: center;
        align-items: center;
        fill: currentColor;
        position: absolute;
        left: 1px;
        bottom: 1px;

        .dark-icon {
          opacity: 0;
          position: absolute;
          top: 0;
          left: 0;
        }

        .light-icon {
          opacity: 1;
          position: absolute;
          top: 0;
          left: 0;
        }
      }
    }
  }
}

.dark {
  .theme-switch-box {
    --bg-color-mute: #2c2c2c;

    .theme-switch {
      .switch__action {
        transform: translate(20px);

        .light-icon {
          opacity: 0;
        }

        .dark-icon {
          opacity: 1;
        }
      }
    }
  }
}

.dark-icon,
.light-icon {
  transition: color var(--el-transition-duration), opacity var(--el-transition-duration);
}
</style>