import {authUtils} from "@/util/auth/auth-utils";
import {ResultStatusEnum} from "@/util/http/ajax-types";
import {ajaxSso} from "@/util/http/impl/sso-ajax-utils";

class AuthScheduled {

  /**
   * 定时刷新token，每10秒执行一次
   */
  public refreshToken() {
    // 如果超时了则进行token的更新，刷新token的前提是要存在token
    if (authUtils.getAccessToken() && authUtils.isTimeout()) {
      ajaxSso.get(`sso_auth/web/refresh_access_token`, null, 2000).then(result => {
        if (result.status === ResultStatusEnum.SUCCESS) {
          authUtils.updateToken(result.data);
        } else {
          console.error(`定期刷新token失败 ${result}`)
        }
      }).catch(reason => {
        console.error(`定期刷新token失败 ${reason}`)
      })
    }
    setTimeout(authScheduled.refreshToken, 1000 * 10)
  }

}

export const authScheduled = new AuthScheduled();